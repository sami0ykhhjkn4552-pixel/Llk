package com.keyboard.kyntra

import android.app.Application
import android.content.Context
import androidx.appcompat.app.AppCompatDelegate
import androidx.room.Room
import com.keyboard.kyntra.secrets.SecretDatabase
import com.keyboard.kyntra.utils.SharedPrefs

class KyntraKeyboardApp : Application() {

    companion object {
        lateinit var instance: KyntraKeyboardApp
            private set
        
        lateinit var secretDatabase: SecretDatabase
            private set
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        
        // تهيئة قاعدة بيانات الأسرار
        secretDatabase = Room.databaseBuilder(
            applicationContext,
            SecretDatabase::class.java,
            "kyntra_secrets.db"
        )
        .fallbackToDestructiveMigration()
        .build()
        
        // تطبيق السمة من الإعدادات
        applyThemeFromPrefs()
    }

    private fun applyThemeFromPrefs() {
        val themeMode = SharedPrefs.getThemeMode(this)
        when (themeMode) {
            "dark" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            "light" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            "high_contrast" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            else -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
        }
    }
}