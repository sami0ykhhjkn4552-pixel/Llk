package com.keyboard.kyntra.keyboard

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.widget.Toast
import com.keyboard.kyntra.R
import com.keyboard.kyntra.utils.SharedPrefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class InvisiblePasteHelper(private val context: Context) {
    
    companion object {
        private const val TAG = "InvisiblePasteHelper"
        private const val PASTE_DELAY_MS = 50L // تأخير بسيط قبل اللصق
        private const val CLEAR_DELAY_MS = 100L // تأخير قبل مسح الحافظة
        
        // أنواع المحتوى التي يمكن لصقها
        enum class ContentType {
            PLAIN_TEXT,
            PASSWORD,
            EMAIL,
            CREDIT_CARD,
            PHONE_NUMBER,
            SECRET_CODE
        }
    }
    
    private val clipboardManager = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    private val handler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(Dispatchers.IO)
    
    /**
     * لصق سر بطريقة مخفية
     */
    fun pasteSecret(secret: String, inputConnection: InputConnection) {
        scope.launch {
            // حفظ محتوى الحافظة الحالي
            val originalClipboard = saveOriginalClipboard()
            
            // نسخ السر إلى الحافظة مؤقتًا
            copyToClipboard(secret)
            
            // انتظار بسيط للتأكد من نسخ البيانات
            withContext(Dispatchers.Main) {
                handler.postDelayed({
                    // لصق السر
                    performPaste(inputConnection)
                    
                    // استعادة الحافظة الأصلية بعد تأخير
                    handler.postDelayed({
                        restoreOriginalClipboard(originalClipboard)
                        
                        // إظهار رسالة تأكيد
                        if (SharedPrefs.getShowPasteNotification(context)) {
                            showPasteNotification()
                        }
                    }, CLEAR_DELAY_MS)
                }, PASTE_DELAY_MS)
            }
        }
    }
    
    /**
     * لصق نص مع تحديد نوعه
     */
    fun pasteTextWithType(
        text: String,
        inputConnection: InputConnection,
        contentType: ContentType = ContentType.PLAIN_TEXT
    ) {
        scope.launch {
            // حفظ محتوى الحافظة الحالي
            val originalClipboard = saveOriginalClipboard()
            
            // نسخ النص إلى الحافظة مع وصف مناسب
            val label = when (contentType) {
                ContentType.PASSWORD -> "Password"
                ContentType.EMAIL -> "Email"
                ContentType.CREDIT_CARD -> "Credit Card"
                ContentType.PHONE_NUMBER -> "Phone Number"
                ContentType.SECRET_CODE -> "Secret Code"
                else -> "Text"
            }
            
            copyToClipboardWithLabel(text, label)
            
            withContext(Dispatchers.Main) {
                handler.postDelayed({
                    // لصق النص
                    performPaste(inputConnection)
                    
                    // استعادة الحافظة الأصلية
                    handler.postDelayed({
                        restoreOriginalClipboard(originalClipboard)
                        
                        // تسجيل الحدث
                        logPasteEvent(contentType, text.length)
                    }, CLEAR_DELAY_MS)
                }, PASTE_DELAY_MS)
            }
        }
    }
    
    /**
     * لصق كلمة مرور مع إخفاءها
     */
    fun pastePassword(password: String, inputConnection: InputConnection) {
        if (password.isEmpty()) return
        
        scope.launch {
            val originalClipboard = saveOriginalClipboard()
            
            // نسخ كلمة المرور
            copyToClipboardWithLabel(password, "Password")
            
            withContext(Dispatchers.Main) {
                handler.postDelayed({
                    // لصق كلمة المرور
                    performPaste(inputConnection)
                    
                    // إضافة نجوم لإخفاء كلمة المرور في بعض الحقول
                    if (shouldMaskPassword(inputConnection)) {
                        handler.postDelayed({
                            maskPassword(password.length, inputConnection)
                        }, 200)
                    }
                    
                    handler.postDelayed({
                        restoreOriginalClipboard(originalClipboard)
                        
                        // إشعار بنجاح اللصق
                        if (SharedPrefs.getShowPasteNotification(context)) {
                            showPasswordPasteNotification()
                        }
                    }, CLEAR_DELAY_MS)
                }, PASTE_DELAY_MS)
            }
        }
    }
    
    /**
     * لصق نص مع تنسيق ذكي
     */
    fun pasteWithSmartFormatting(
        text: String,
        inputConnection: InputConnection,
        editorInfo: EditorInfo?
    ) {
        scope.launch {
            val originalClipboard = saveOriginalClipboard()
            
            // تحليل نوع الحقل وتطبيق التنسيق المناسب
            val formattedText = formatTextForField(text, editorInfo)
            
            copyToClipboard(formattedText)
            
            withContext(Dispatchers.Main) {
                handler.postDelayed({
                    performPaste(inputConnection)
                    
                    handler.postDelayed({
                        restoreOriginalClipboard(originalClipboard)
                        
                        // تسجيل الاستخدام
                        recordSmartPasteUsage(editorInfo)
                    }, CLEAR_DELAY_MS)
                }, PASTE_DELAY_MS)
            }
        }
    }
    
    /**
     * حفظ محتوى الحافظة الحالي
     */
    private fun saveOriginalClipboard(): ClipData? {
        return try {
            if (clipboardManager.hasPrimaryClip()) {
                clipboardManager.primaryClip
            } else {
                null
            }
        } catch (e: Exception) {
            null
        }
    }
    
    /**
     * نسخ نص إلى الحافظة
     */
    private fun copyToClipboard(text: String) {
        val clip = ClipData.newPlainText("KyntraSecret", text)
        clipboardManager.setPrimaryClip(clip)
    }
    
    /**
     * نسخ نص إلى الحافظة مع تسمية
     */
    private fun copyToClipboardWithLabel(text: String, label: String) {
        val clip = ClipData.newPlainText(label, text)
        clipboardManager.setPrimaryClip(clip)
    }
    
    /**
     * استعادة الحافظة الأصلية
     */
    private fun restoreOriginalClipboard(originalClip: ClipData?) {
        try {
            if (originalClip != null) {
                clipboardManager.setPrimaryClip(originalClip)
            } else {
                // إذا لم يكن هناك محتوى أصلي، نمسح الحافظة
                clearClipboard()
            }
        } catch (e: Exception) {
            // في حالة الخطأ، نمسح الحافظة
            clearClipboard()
        }
    }
    
    /**
     * مسح الحافظة
     */
    private fun clearClipboard() {
        val emptyClip = ClipData.newPlainText("", "")
        clipboardManager.setPrimaryClip(emptyClip)
    }
    
    /**
     * تنفيذ عملية اللصق
     */
    private fun performPaste(inputConnection: InputConnection) {
        try {
            // محاولة استخدام مفتاح اللصق (Ctrl+V)
            inputConnection.sendKeyEvent(android.view.KeyEvent(
                android.view.KeyEvent.ACTION_DOWN,
                android.view.KeyEvent.KEYCODE_V
            ))
            
            // إضافة مفتاح التحكم
            inputConnection.sendKeyEvent(android.view.KeyEvent(
                android.view.KeyEvent.ACTION_DOWN,
                android.view.KeyEvent.KEYCODE_CTRL_LEFT
            ))
            
            // تحرير المفاتيح
            inputConnection.sendKeyEvent(android.view.KeyEvent(
                android.view.KeyEvent.ACTION_UP,
                android.view.KeyEvent.KEYCODE_V
            ))
            
            inputConnection.sendKeyEvent(android.view.KeyEvent(
                android.view.KeyEvent.ACTION_UP,
                android.view.KeyEvent.KEYCODE_CTRL_LEFT
            ))
            
            // طريقة احتياطية: لصق مباشر
            if (!inputConnection.commitText(clipboardManager.primaryClip?.getItemAt(0)?.text, 1)) {
                // إذا فشلت الطريقة الأولى، نجرب الطريقة البديلة
                pasteAlternativeMethod(inputConnection)
            }
        } catch (e: Exception) {
            // طريقة الطوارئ: إدخال النص مباشرة
            pasteEmergencyMethod(inputConnection)
        }
    }
    
    /**
     * طريقة لصق بديلة
     */
    private fun pasteAlternativeMethod(inputConnection: InputConnection) {
        try {
            // محاكاة اختصار Ctrl+V
            inputConnection.performContextMenuAction(android.R.id.paste)
        } catch (e: Exception) {
            pasteEmergencyMethod(inputConnection)
        }
    }
    
    /**
     * طريقة لصق الطوارئ
     */
    private fun pasteEmergencyMethod(inputConnection: InputConnection) {
        val text = clipboardManager.primaryClip?.getItemAt(0)?.text?.toString()
        if (!text.isNullOrEmpty()) {
            inputConnection.commitText(text, 1)
        }
    }
    
    /**
     * إخفاء كلمة المرور بالنجوم
     */
    private fun maskPassword(length: Int, inputConnection: InputConnection) {
        // حذف الأحرف الأصلية
        inputConnection.deleteSurroundingText(length, 0)
        
        // إدخال نجوم بدلاً منها
        val stars = "*".repeat(length)
        inputConnection.commitText(stars, 1)
    }
    
    /**
     * التحقق مما إذا كان يجب إخفاء كلمة المرور
     */
    private fun shouldMaskPassword(inputConnection: InputConnection): Boolean {
        // هنا يمكن إضافة منطق للتحقق من نوع الحقل
        // حاليًا نعود بالقيمة الافتراضية من الإعدادات
        return SharedPrefs.getMaskPasswords(context)
    }
    
    /**
     * تنسيق النص بناءً على نوع الحقل
     */
    private fun formatTextForField(text: String, editorInfo: EditorInfo?): String {
        if (editorInfo == null) return text
        
        return when (editorInfo.inputType and EditorInfo.TYPE_MASK_CLASS) {
            EditorInfo.TYPE_CLASS_TEXT -> {
                when (editorInfo.inputType and EditorInfo.TYPE_MASK_VARIATION) {
                    EditorInfo.TYPE_TEXT_VARIATION_EMAIL_ADDRESS -> formatEmail(text)
                    EditorInfo.TYPE_TEXT_VARIATION_PERSON_NAME -> formatName(text)
                    EditorInfo.TYPE_TEXT_VARIATION_POSTAL_ADDRESS -> formatAddress(text)
                    EditorInfo.TYPE_TEXT_VARIATION_PHONETIC -> text
                    else -> text
                }
            }
            EditorInfo.TYPE_CLASS_NUMBER -> formatNumber(text, editorInfo)
            EditorInfo.TYPE_CLASS_PHONE -> formatPhoneNumber(text)
            EditorInfo.TYPE_CLASS_DATETIME -> formatDateTime(text)
            else -> text
        }
    }
    
    /**
     * تنسيق البريد الإلكتروني
     */
    private fun formatEmail(text: String): String {
        return text.trim().lowercase()
    }
    
    /**
     * تنسيق الاسم
     */
    private fun formatName(text: String): String {
        return text.trim().split(" ")
            .joinToString(" ") { it.replaceFirstChar { char -> char.uppercase() } }
    }
    
    /**
     * تنسيق العنوان
     */
    private fun formatAddress(text: String): String {
        return text.trim()
    }
    
    /**
     * تنسيق الأرقام
     */
    private fun formatNumber(text: String, editorInfo: EditorInfo): String {
        val number = text.replace(Regex("[^0-9]"), "")
        
        return when (editorInfo.inputType and EditorInfo.TYPE_MASK_VARIATION) {
            EditorInfo.TYPE_NUMBER_VARIATION_PASSWORD -> number
            EditorInfo.TYPE_NUMBER_FLAG_DECIMAL -> {
                if (number.contains('.')) number else "$number.0"
            }
            else -> number
        }
    }
    
    /**
     * تنسيق رقم الهاتف
     */
    private fun formatPhoneNumber(text: String): String {
        val digits = text.replace(Regex("[^0-9]"), "")
        
        return when {
            digits.length == 10 -> "(${digits.substring(0, 3)}) ${digits.substring(3, 6)}-${digits.substring(6)}"
            digits.length == 11 && digits.startsWith("1") -> 
                "+1 (${digits.substring(1, 4)}) ${digits.substring(4, 7)}-${digits.substring(7)}"
            else -> digits
        }
    }
    
    /**
     * تنسيق التاريخ والوقت
     */
    private fun formatDateTime(text: String): String {
        return try {
            // محاولة تحويل إلى تنسيق قياسي
            java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault())
                .format(java.util.Date(text.toLong()))
        } catch (e: Exception) {
            text
        }
    }
    
    /**
     * إظهار إشعار اللصق
     */
    private fun showPasteNotification() {
        Toast.makeText(
            context,
            context.getString(R.string.secret_pasted),
            Toast.LENGTH_SHORT
        ).show()
    }
    
    /**
     * إظهار إشعار لصق كلمة المرور
     */
    private fun showPasswordPasteNotification() {
        Toast.makeText(
            context,
            context.getString(R.string.password_pasted),
            Toast.LENGTH_SHORT
        ).show()
    }
    
    /**
     * تسجيل حدث اللصق
     */
    private fun logPasteEvent(contentType: ContentType, length: Int) {
        // يمكن تسجيل الإحصائيات هنا (محليًا فقط، بدون إرسال للسيرفر)
        val stats = SharedPrefs.getPasteStats(context).toMutableMap()
        val key = contentType.name.lowercase()
        val currentCount = stats[key] ?: 0
        stats[key] = currentCount + 1
        
        // تحديث إحصائيات الطول
        val lengthStats = SharedPrefs.getPasteLengthStats(context).toMutableMap()
        val lengthKey = when (length) {
            in 1..10 -> "short"
            in 11..50 -> "medium"
            in 51..100 -> "long"
            else -> "very_long"
        }
        val currentLengthCount = lengthStats[lengthKey] ?: 0
        lengthStats[lengthKey] = currentLengthCount + 1
        
        SharedPrefs.setPasteStats(context, stats)
        SharedPrefs.setPasteLengthStats(context, lengthStats)
    }
    
    /**
     * تسجيل استخدام اللصق الذكي
     */
    private fun recordSmartPasteUsage(editorInfo: EditorInfo?) {
        if (editorInfo != null) {
            val fieldType = when (editorInfo.inputType and EditorInfo.TYPE_MASK_CLASS) {
                EditorInfo.TYPE_CLASS_TEXT -> "text"
                EditorInfo.TYPE_CLASS_NUMBER -> "number"
                EditorInfo.TYPE_CLASS_PHONE -> "phone"
                EditorInfo.TYPE_CLASS_DATETIME -> "datetime"
                else -> "other"
            }
            
            val stats = SharedPrefs.getSmartPasteStats(context).toMutableMap()
            val currentCount = stats[fieldType] ?: 0
            stats[fieldType] = currentCount + 1
            
            SharedPrefs.setSmartPasteStats(context, stats)
        }
    }
    
    /**
     * الحصول على إحصائيات اللصق
     */
    fun getPasteStatistics(): Map<String, Any> {
        val pasteStats = SharedPrefs.getPasteStats(context)
        val lengthStats = SharedPrefs.getPasteLengthStats(context)
        val smartStats = SharedPrefs.getSmartPasteStats(context)
        
        return mapOf(
            "total_pastes" to pasteStats.values.sum(),
            "by_type" to pasteStats,
            "by_length" to lengthStats,
            "smart_pastes" to smartStats
        )
    }
    
    /**
     * مسح إحصائيات اللصق
     */
    fun clearPasteStatistics() {
        SharedPrefs.clearPasteStats(context)
        SharedPrefs.clearPasteLengthStats(context)
        SharedPrefs.clearSmartPasteStats(context)
    }
    
    /**
     * التحقق من إمكانية الوصول للحافظة
     */
    fun canAccessClipboard(): Boolean {
        return try {
            clipboardManager.hasPrimaryClip()
            true
        } catch (e: SecurityException) {
            false
        } catch (e: Exception) {
            true
        }
    }
}