package com.keyboard.kyntra.keyboard

import android.content.Context
import android.inputmethodservice.Keyboard
import com.keyboard.kyntra.R
import com.keyboard.kyntra.utils.SharedPrefs

class KeyboardLayoutManager(private val context: Context) {
    
    enum class KeyboardType {
        TEXT,
        NUMERIC,
        SYMBOLS,
        EMOJI,
        PHONE,
        PASSWORD,
        EMAIL,
        URL
    }
    
    private var currentKeyboardType = KeyboardType.TEXT
    private var currentLanguageCode = "en"
    private var isCapsLock = false
    private var isSymbolsMode = false
    private var isEmojiMode = false
    
    private val keyboardCache = mutableMapOf<String, Keyboard>()
    
    init {
        // تحميل اللغة الحالية من الإعدادات
        currentLanguageCode = SharedPrefs.getCurrentLanguage(context)
    }
    
    /**
     * الحصول على لوحة المفاتيح الحالية
     */
    fun getCurrentKeyboard(): Keyboard {
        val cacheKey = buildCacheKey()
        
        return keyboardCache[cacheKey] ?: run {
            val keyboard = createKeyboard()
            keyboardCache[cacheKey] = keyboard
            keyboard
        }
    }
    
    /**
     * إنشاء مفتاح ذاكرة التخزين المؤقت
     */
    private fun buildCacheKey(): String {
        return "${currentLanguageCode}_${currentKeyboardType}_${isCapsLock}_${isSymbolsMode}_${isEmojiMode}"
    }
    
    /**
     * إنشاء لوحة مفاتيح جديدة
     */
    private fun createKeyboard(): Keyboard {
        return when {
            isEmojiMode -> createEmojiKeyboard()
            isSymbolsMode -> createSymbolsKeyboard()
            else -> createLanguageKeyboard()
        }
    }
    
    /**
     * إنشاء لوحة مفاتيح اللغة
     */
    private fun createLanguageKeyboard(): Keyboard {
        val layoutResId = when (currentLanguageCode) {
            "en" -> R.xml.keyboard_english
            "ar" -> R.xml.keyboard_arabic
            "fr" -> R.xml.keyboard_french
            "de" -> R.xml.keyboard_german
            "es" -> R.xml.keyboard_spanish
            "ru" -> R.xml.keyboard_russian
            "ja" -> R.xml.keyboard_japanese
            "ko" -> R.xml.keyboard_korean
            "hi" -> R.xml.keyboard_hindi
            "tr" -> R.xml.keyboard_turkish
            else -> R.xml.keyboard_english
        }
        
        return Keyboard(context, layoutResId).apply {
            // تطبيق إعدادات Caps Lock
            if (isCapsLock) {
                keys.forEach { key ->
                    if (key.label != null && key.label!!.length == 1 && key.label!![0].isLetter()) {
                        key.label = key.label!!.uppercase()
                        key.codes[0] = key.label!![0].code
                    }
                }
            }
        }
    }
    
    /**
     * إنشاء لوحة مفاتيح الرموز
     */
    private fun createSymbolsKeyboard(): Keyboard {
        return Keyboard(context, R.xml.keyboard_symbols).apply {
            // يمكن تخصيص الرموز هنا
            customizeSymbolsKeyboard()
        }
    }
    
    /**
     * إنشاء لوحة مفاتيح الإيموجيات
     */
    private fun createEmojiKeyboard(): Keyboard {
        return Keyboard(context, R.xml.keyboard_emoji).apply {
            // يمكن تخصيص الإيموجيات هنا
            customizeEmojiKeyboard()
        }
    }
    
    /**
     * تخصيص لوحة مفاتيح الرموز
     */
    private fun customizeSymbolsKeyboard() {
        // يمكن إضافة منطق التخصيص هنا
    }
    
    /**
     * تخصيص لوحة مفاتيح الإيموجيات
     */
    private fun customizeEmojiKeyboard() {
        // يمكن إضافة منطق التخصيص هنا
    }
    
    /**
     * تعيين لغة لوحة المفاتيح
     */
    fun setCurrentLanguage(languageCode: String) {
        if (currentLanguageCode != languageCode) {
            currentLanguageCode = languageCode
            clearCache()
            SharedPrefs.setCurrentLanguage(context, languageCode)
        }
    }
    
    /**
     * تعيين نوع لوحة المفاتيح
     */
    fun setCurrentKeyboardType(type: KeyboardType) {
        if (currentKeyboardType != type) {
            currentKeyboardType = type
            clearCache()
        }
    }
    
    /**
     * تعيين حالة Caps Lock
     */
    fun setCapsLock(enabled: Boolean) {
        if (isCapsLock != enabled) {
            isCapsLock = enabled
            clearCache()
        }
    }
    
    /**
     * تعيين وضع الرموز
     */
    fun setSymbolsMode(enabled: Boolean) {
        if (isSymbolsMode != enabled) {
            isSymbolsMode = enabled
            if (enabled) isEmojiMode = false
            clearCache()
        }
    }
    
    /**
     * تعيين وضع الإيموجيات
     */
    fun setEmojiMode(enabled: Boolean) {
        if (isEmojiMode != enabled) {
            isEmojiMode = enabled
            if (enabled) isSymbolsMode = false
            clearCache()
        }
    }
    
    /**
     * تبديل حالة Caps Lock
     */
    fun toggleCapsLock() {
        setCapsLock(!isCapsLock)
    }
    
    /**
     * تبديل وضع الرموز
     */
    fun toggleSymbolsMode() {
        setSymbolsMode(!isSymbolsMode)
    }
    
    /**
     * تبديل وضع الإيموجيات
     */
    fun toggleEmojiMode() {
        setEmojiMode(!isEmojiMode)
    }
    
    /**
     * الحصول على اللغة الحالية
     */
    fun getCurrentLanguage(): String {
        return currentLanguageCode
    }
    
    /**
     * الحصول على نوع لوحة المفاتيح الحالية
     */
    fun getCurrentKeyboardType(): KeyboardType {
        return currentKeyboardType
    }
    
    /**
     * التحقق مما إذا كان Caps Lock مفعلًا
     */
    fun isCapsLockEnabled(): Boolean {
        return isCapsLock
    }
    
    /**
     * التحقق مما إذا كان وضع الرموز مفعلًا
     */
    fun isSymbolsModeEnabled(): Boolean {
        return isSymbolsMode
    }
    
    /**
     * التحقق مما إذا كان وضع الإيموجيات مفعلًا
     */
    fun isEmojiModeEnabled(): Boolean {
        return isEmojiMode
    }
    
    /**
     * مسح ذاكرة التخزين المؤقت
     */
    fun clearCache() {
        keyboardCache.clear()
    }
    
    /**
     * الحصول على حجم ذاكرة التخزين المؤقت
     */
    fun getCacheSize(): Int {
        return keyboardCache.size
    }
    
    /**
     * تبديل إلى لوحة المفاتيح التالية
     */
    fun switchToNextKeyboard(): KeyboardType {
        val types = KeyboardType.values()
        val currentIndex = types.indexOf(currentKeyboardType)
        val nextIndex = (currentIndex + 1) % types.size
        val nextType = types[nextIndex]
        
        setCurrentKeyboardType(nextType)
        return nextType
    }
    
    /**
     * تبديل إلى لوحة المفاتيح السابقة
     */
    fun switchToPreviousKeyboard(): KeyboardType {
        val types = KeyboardType.values()
        val currentIndex = types.indexOf(currentKeyboardType)
        val prevIndex = (currentIndex - 1 + types.size) % types.size
        val prevType = types[prevIndex]
        
        setCurrentKeyboardType(prevType)
        return prevType
    }
    
    /**
     * تبديل إلى اللغة التالية
     */
    fun switchToNextLanguage(): String {
        val languages = listOf("en", "ar", "fr", "de", "es", "ru", "ja", "ko", "hi", "tr")
        val currentIndex = languages.indexOf(currentLanguageCode)
        val nextIndex = (currentIndex + 1) % languages.size
        val nextLanguage = languages[nextIndex]
        
        setCurrentLanguage(nextLanguage)
        return nextLanguage
    }
    
    /**
     * الحصول على تخطيط لوحة المفاتيح للغة المحددة
     */
    fun getKeyboardLayout(languageCode: String): Int {
        return when (languageCode) {
            "en" -> R.xml.keyboard_english
            "ar" -> R.xml.keyboard_arabic
            "fr" -> R.xml.keyboard_french
            "de" -> R.xml.keyboard_german
            "es" -> R.xml.keyboard_spanish
            "ru" -> R.xml.keyboard_russian
            "ja" -> R.xml.keyboard_japanese
            "ko" -> R.xml.keyboard_korean
            "hi" -> R.xml.keyboard_hindi
            "tr" -> R.xml.keyboard_turkish
            else -> R.xml.keyboard_english
        }
    }
    
    /**
     * التحقق مما إذا كانت اللغة تدعم الكتابة من اليمين لليسار
     */
    fun isRTL(languageCode: String): Boolean {
        return when (languageCode) {
            "ar" -> true
            else -> false
        }
    }
    
    /**
     * الحصول على اتجاه النص للغة الحالية
     */
    fun getTextDirection(): Int {
        return if (isRTL(currentLanguageCode)) {
            android.view.View.TEXT_DIRECTION_RTL
        } else {
            android.view.View.TEXT_DIRECTION_LTR
        }
    }
    
    /**
     * تهيئة لوحة المفاتيح بناءً على نوع الإدخال
     */
    fun initializeForInputType(inputType: Int) {
        when {
            (inputType and android.text.InputType.TYPE_MASK_CLASS) == android.text.InputType.TYPE_CLASS_TEXT -> {
                when {
                    (inputType and android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD) != 0 -> 
                        setCurrentKeyboardType(KeyboardType.PASSWORD)
                    (inputType and android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS) != 0 -> 
                        setCurrentKeyboardType(KeyboardType.EMAIL)
                    (inputType and android.text.InputType.TYPE_TEXT_VARIATION_URI) != 0 -> 
                        setCurrentKeyboardType(KeyboardType.URL)
                    else -> setCurrentKeyboardType(KeyboardType.TEXT)
                }
            }
            (inputType and android.text.InputType.TYPE_MASK_CLASS) == android.text.InputType.TYPE_CLASS_NUMBER -> {
                setCurrentKeyboardType(KeyboardType.NUMERIC)
            }
            (inputType and android.text.InputType.TYPE_MASK_CLASS) == android.text.InputType.TYPE_CLASS_PHONE -> {
                setCurrentKeyboardType(KeyboardType.PHONE)
            }
            else -> {
                setCurrentKeyboardType(KeyboardType.TEXT)
            }
        }
    }
    
    /**
     * الحصول على معلومات حول لوحة المفاتيح الحالية
     */
    fun getKeyboardInfo(): Map<String, Any> {
        return mapOf(
            "language" to currentLanguageCode,
            "type" to currentKeyboardType.name,
            "caps_lock" to isCapsLock,
            "symbols_mode" to isSymbolsMode,
            "emoji_mode" to isEmojiMode,
            "cache_size" to keyboardCache.size,
            "is_rtl" to isRTL(currentLanguageCode)
        )
    }
    
    /**
     * إعادة تعيين لوحة المفاتيح إلى الوضع الافتراضي
     */
    fun resetToDefault() {
        currentKeyboardType = KeyboardType.TEXT
        isCapsLock = false
        isSymbolsMode = false
        isEmojiMode = false
        clearCache()
    }
}