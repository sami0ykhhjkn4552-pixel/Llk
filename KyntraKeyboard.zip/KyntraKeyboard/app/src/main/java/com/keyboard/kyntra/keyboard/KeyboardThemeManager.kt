package com.keyboard.kyntra.keyboard

import android.content.Context
import android.graphics.Color
import com.keyboard.kyntra.utils.SharedPrefs

data class KeyboardTheme(
    val name: String,
    val backgroundColor: Int,
    val keyBackgroundColor: Int,
    val keyTextColor: Int,
    val keyPressedColor: Int,
    val keyBorderColor: Int,
    val keyShadowColor: Int,
    val keySpecialColor: Int,
    val isHighContrast: Boolean = false
)

class KeyboardThemeManager private constructor(context: Context) {

    companion object {
        @Volatile
        private var instance: KeyboardThemeManager? = null

        fun getInstance(context: Context): KeyboardThemeManager =
            instance ?: synchronized(this) {
                instance ?: KeyboardThemeManager(context.applicationContext).also { instance = it }
            }
    }

    private val context = context.applicationContext

    // السمة الداكنة
    private val darkTheme = KeyboardTheme(
        name = "dark",
        backgroundColor = Color.parseColor("#1E1E1E"),
        keyBackgroundColor = Color.parseColor("#2D2D2D"),
        keyTextColor = Color.parseColor("#FFFFFF"),
        keyPressedColor = Color.parseColor("#3D3D3D"),
        keyBorderColor = Color.parseColor("#404040"),
        keyShadowColor = Color.parseColor("#000000"),
        keySpecialColor = Color.parseColor("#007ACC")
    )

    // السمة الفاتحة
    private val lightTheme = KeyboardTheme(
        name = "light",
        backgroundColor = Color.parseColor("#F5F5F5"),
        keyBackgroundColor = Color.parseColor("#FFFFFF"),
        keyTextColor = Color.parseColor("#212121"),
        keyPressedColor = Color.parseColor("#E0E0E0"),
        keyBorderColor = Color.parseColor("#BDBDBD"),
        keyShadowColor = Color.parseColor("#9E9E9E"),
        keySpecialColor = Color.parseColor("#2196F3")
    )

    // سمة التباين العالي
    private val highContrastTheme = KeyboardTheme(
        name = "high_contrast",
        backgroundColor = Color.parseColor("#000000"),
        keyBackgroundColor = Color.parseColor("#FFFFFF"),
        keyTextColor = Color.parseColor("#000000"),
        keyPressedColor = Color.parseColor("#FFFF00"),
        keyBorderColor = Color.parseColor("#FFFFFF"),
        keyShadowColor = Color.parseColor("#000000"),
        keySpecialColor = Color.parseColor("#FF0000"),
        isHighContrast = true
    )

    private val themes = mapOf(
        "dark" to darkTheme,
        "light" to lightTheme,
        "high_contrast" to highContrastTheme
    )

    fun getCurrentTheme(): KeyboardTheme {
        val themeName = SharedPrefs.getThemeMode(context)
        return themes[themeName] ?: darkTheme
    }

    fun getAllThemes(): List<KeyboardTheme> {
        return themes.values.toList()
    }

    fun setTheme(themeName: String) {
        if (themes.containsKey(themeName)) {
            SharedPrefs.setThemeMode(context, themeName)
        }
    }

    fun getNextTheme(currentThemeName: String): KeyboardTheme {
        val themeList = themes.values.toList()
        val currentIndex = themeList.indexOfFirst { it.name == currentThemeName }
        val nextIndex = (currentIndex + 1) % themeList.size
        return themeList[nextIndex]
    }

    // إنشاء ألوان متدرجة بناءً على السمة
    fun getGradientColors(theme: KeyboardTheme): IntArray {
        return when (theme.name) {
            "dark" -> intArrayOf(
                Color.parseColor("#1E1E1E"),
                Color.parseColor("#252526"),
                Color.parseColor("#2D2D30")
            )
            "light" -> intArrayOf(
                Color.parseColor("#F5F5F5"),
                Color.parseColor("#EEEEEE"),
                Color.parseColor("#E0E0E0")
            )
            "high_contrast" -> intArrayOf(
                Color.parseColor("#000000"),
                Color.parseColor("#FFFFFF"),
                Color.parseColor("#000000")
            )
            else -> intArrayOf(
                Color.parseColor("#1E1E1E"),
                Color.parseColor("#252526"),
                Color.parseColor("#2D2D30")
            )
        }
    }

    // الحصول على لون الحالة (للأزرار الخاصة)
    fun getStateColor(theme: KeyboardTheme, isPressed: Boolean): Int {
        return if (isPressed) {
            theme.keyPressedColor
        } else {
            theme.keyBackgroundColor
        }
    }

    // الحصول على لون النص بناءً على الخلفية (لضمان القابلية للقراءة)
    fun getTextColorForBackground(backgroundColor: Int): Int {
        // حساب النصرة للون الخلفية
        val darkness = 1 - (0.299 * Color.red(backgroundColor) + 
                          0.587 * Color.green(backgroundColor) + 
                          0.114 * Color.blue(backgroundColor)) / 255
        
        return if (darkness < 0.5) {
            Color.BLACK // لون فاتح
        } else {
            Color.WHITE // لون داكن
        }
    }

    // توليد تدرج ألوان للمفاتيح
    fun generateKeyGradient(theme: KeyboardTheme): android.graphics.drawable.GradientDrawable {
        val gradient = android.graphics.drawable.GradientDrawable()
        gradient.cornerRadii = floatArrayOf(8f, 8f, 8f, 8f, 8f, 8f, 8f, 8f)
        
        val colors = when (theme.name) {
            "dark" -> intArrayOf(
                Color.parseColor("#3C3C3C"),
                Color.parseColor("#2D2D2D"),
                Color.parseColor("#252525")
            )
            "light" -> intArrayOf(
                Color.parseColor("#FFFFFF"),
                Color.parseColor("#FAFAFA"),
                Color.parseColor("#F0F0F0")
            )
            "high_contrast" -> intArrayOf(
                Color.WHITE,
                Color.WHITE,
                Color.WHITE
            )
            else -> intArrayOf(
                Color.parseColor("#3C3C3C"),
                Color.parseColor("#2D2D2D"),
                Color.parseColor("#252525")
            )
        }
        
        gradient.colors = colors
        gradient.setStroke(1, theme.keyBorderColor)
        
        return gradient
    }

    // إنشاء تأثير الظل للمفاتيح
    fun createKeyShadow(theme: KeyboardTheme): android.graphics.drawable.LayerDrawable {
        val shadowColor = theme.keyShadowColor
        
        val shadow = android.graphics.drawable.GradientDrawable()
        shadow.cornerRadii = floatArrayOf(8f, 8f, 8f, 8f, 8f, 8f, 8f, 8f)
        shadow.setColor(shadowColor)
        
        val background = android.graphics.drawable.GradientDrawable()
        background.cornerRadii = floatArrayOf(8f, 8f, 8f, 8f, 8f, 8f, 8f, 8f)
        background.setColor(theme.keyBackgroundColor)
        background.setStroke(1, theme.keyBorderColor)
        
        return android.graphics.drawable.LayerDrawable(arrayOf(shadow, background)).apply {
            setLayerInset(1, 0, 0, 2, 2) // إزاحة الخلفية لخلق تأثير الظل
        }
    }

    // الحصول على لون خاص للمفاتيح المميزة
    fun getSpecialKeyColor(theme: KeyboardTheme): Int {
        return when (theme.name) {
            "dark" -> Color.parseColor("#0E639C")
            "light" -> Color.parseColor("#1976D2")
            "high_contrast" -> Color.parseColor("#FF0000")
            else -> Color.parseColor("#0E639C")
        }
    }
}