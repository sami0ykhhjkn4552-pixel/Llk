package com.keyboard.kyntra.keyboard

import android.inputmethodservice.InputMethodService
import android.inputmethodservice.Keyboard
import android.inputmethodservice.KeyboardView
import android.media.AudioManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.text.TextUtils
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.widget.Toast
import com.keyboard.kyntra.R
import com.keyboard.kyntra.keyboard.InvisiblePasteHelper
import com.keyboard.kyntra.keyboard.KeyboardLayoutManager
import com.keyboard.kyntra.keyboard.LanguageManager
import com.keyboard.kyntra.keyboard.SecretDetector
import com.keyboard.kyntra.keyboard.SymbolsManager
import com.keyboard.kyntra.utils.SharedPrefs
import com.keyboard.kyntra.utils.SoundHelper
import com.keyboard.kyntra.utils.VibrationHelper
import com.keyboard.kyntra.utils.WordFilterExtended

class KyntraKeyboardService : InputMethodService(), KeyboardView.OnKeyboardActionListener {

    private lateinit var keyboardView: KeyboardView
    private lateinit var keyboardLayoutManager: KeyboardLayoutManager
    private lateinit var languageManager: LanguageManager
    private lateinit var symbolsManager: SymbolsManager
    private lateinit var secretDetector: SecretDetector
    private lateinit var invisiblePasteHelper: InvisiblePasteHelper
    private lateinit var wordFilter: WordFilterExtended
    
    private var currentKeyboard: Keyboard? = null
    private var capsLock = false
    private var isSymbolsMode = false
    private var isEmojiMode = false
    private var currentInputType = 0
    
    private var currentTextBuffer = StringBuilder()
    private val secretTriggerPatterns = listOf("A56", "B23", "C89", "X12", "P34")

    override fun onCreate() {
        super.onCreate()
        
        // تهيئة المديرين
        languageManager = LanguageManager(this)
        symbolsManager = SymbolsManager(this)
        secretDetector = SecretDetector(this)
        invisiblePasteHelper = InvisiblePasteHelper(this)
        wordFilter = WordFilterExtended(this)
        
        // تهيئة مدير التخطيط
        keyboardLayoutManager = KeyboardLayoutManager(this)
    }

    override fun onCreateInputView(): View {
        val inflater = LayoutInflater.from(this)
        keyboardView = inflater.inflate(R.layout.keyboard_full, null) as KeyboardView
        
        // إعداد خصائص لوحة المفاتيح
        keyboardView.setOnKeyboardActionListener(this)
        keyboardView.isPreviewEnabled = false // تعطيل المعاينة لتجنب التأخير
        keyboardView.keyboard = keyboardLayoutManager.getCurrentKeyboard()
        currentKeyboard = keyboardView.keyboard
        
        // تطبيق السمة الحالية
        applyCurrentTheme()
        
        return keyboardView
    }

    override fun onStartInput(attribute: EditorInfo?, restarting: Boolean) {
        super.onStartInput(attribute, restarting)
        
        currentInputType = attribute?.inputType ?: 0
        currentTextBuffer.clear()
        
        // تحديد نوع لوحة المفاتيح بناءً على حقل الإدخال
        when {
            attribute?.inputType?.and(EditorInfo.TYPE_MASK_CLASS) == EditorInfo.TYPE_CLASS_TEXT -> {
                if (attribute.inputType and EditorInfo.TYPE_TEXT_VARIATION_PASSWORD != 0) {
                    loadPasswordKeyboard()
                } else {
                    loadTextKeyboard()
                }
            }
            attribute?.inputType?.and(EditorInfo.TYPE_MASK_CLASS) == EditorInfo.TYPE_CLASS_NUMBER -> {
                loadNumericKeyboard()
            }
            attribute?.inputType?.and(EditorInfo.TYPE_MASK_CLASS) == EditorInfo.TYPE_CLASS_PHONE -> {
                loadPhoneKeyboard()
            }
            else -> {
                loadTextKeyboard()
            }
        }
    }

    override fun onKey(primaryCode: Int, keyCodes: IntArray?) {
        val inputConnection = currentInputConnection ?: return
        
        when (primaryCode) {
            // مفاتيح التحكم
            Keyboard.KEYCODE_DELETE -> {
                handleDelete(inputConnection)
            }
            Keyboard.KEYCODE_SHIFT -> {
                handleShift()
            }
            Keyboard.KEYCODE_CANCEL -> {
                handleClose()
            }
            Keyboard.KEYCODE_MODE_CHANGE -> {
                handleLanguageChange()
            }
            Keyboard.KEYCODE_ALT -> {
                handleSymbols()
            }
            Keyboard.KEYCODE_DONE -> {
                handleEnter(inputConnection)
            }
            // كود خاص لإدارة الأسرار
            -100 -> {
                handleSecretMode()
            }
            // كود خاص للإيموجيات
            -101 -> {
                handleEmojiMode()
            }
            // كود خاص لإعدادات لوحة المفاتيح
            -102 -> {
                openKeyboardSettings()
            }
            else -> {
                handleCharacter(primaryCode, inputConnection)
            }
        }
        
        // تشغيل التأثيرات
        playClickEffect()
        vibrateIfEnabled()
    }

    private fun handleCharacter(code: Int, inputConnection: InputConnection) {
        val currentText = currentTextBuffer.toString()
        val char = code.toChar()
        
        // إضافة الحرف إلى المخزن المؤقت
        currentTextBuffer.append(char)
        
        // التحقق من أنماط الأسرار
        secretTriggerPatterns.forEach { pattern ->
            if (currentTextBuffer.endsWith(pattern)) {
                handleSecretPattern(pattern)
                currentTextBuffer.clear()
                return@forEach
            }
        }
        
        // إذا وصل طول النص لـ 10 أحرف، تحقق من وجود كلمات بذيئة
        if (currentTextBuffer.length >= 10) {
            val lastTenChars = currentTextBuffer.takeLast(10).toString()
            if (wordFilter.containsBadWord(lastTenChars)) {
                // حذف الكلمة البذيئة
                inputConnection.deleteSurroundingText(10, 0)
                currentTextBuffer.delete(currentTextBuffer.length - 10, currentTextBuffer.length)
                Toast.makeText(this, R.string.bad_word_blocked, Toast.LENGTH_SHORT).show()
                return
            }
        }
        
        // إدخال الحرف
        inputConnection.commitText(char.toString(), 1)
    }

    private fun handleSecretPattern(pattern: String) {
        val inputConnection = currentInputConnection ?: return
        
        // حذف النمط المكتوب
        inputConnection.deleteSurroundingText(pattern.length, 0)
        
        // البحث عن السر المناسب
        val secret = secretDetector.detectSecret(pattern)
        if (secret != null) {
            // إدخال السر بطريقة مخفية
            invisiblePasteHelper.pasteSecret(secret, inputConnection)
        }
    }

    private fun handleDelete(inputConnection: InputConnection) {
        if (currentTextBuffer.isNotEmpty()) {
            currentTextBuffer.deleteCharAt(currentTextBuffer.length - 1)
        }
        
        val selectedText = inputConnection.getSelectedText(0)
        if (!TextUtils.isEmpty(selectedText)) {
            // حذف النص المحدد
            inputConnection.commitText("", 1)
        } else {
            // حذف حرف واحد قبل المؤشر
            inputConnection.deleteSurroundingText(1, 0)
        }
    }

    private fun handleShift() {
        capsLock = !capsLock
        keyboardLayoutManager.setCapsLock(capsLock)
        keyboardView.keyboard = keyboardLayoutManager.getCurrentKeyboard()
        keyboardView.invalidateAllKeys()
    }

    private fun handleLanguageChange() {
        val nextLanguage = languageManager.getNextLanguage()
        keyboardLayoutManager.setCurrentLanguage(nextLanguage)
        keyboardView.keyboard = keyboardLayoutManager.getCurrentKeyboard()
        keyboardView.invalidateAllKeys()
        
        // عرض اسم اللغة الجديدة
        Toast.makeText(this, 
            getString(R.string.language_changed, nextLanguage.name), 
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun handleSymbols() {
        if (isSymbolsMode) {
            isSymbolsMode = false
            keyboardLayoutManager.setSymbolsMode(false)
        } else {
            isSymbolsMode = true
            isEmojiMode = false
            keyboardLayoutManager.setSymbolsMode(true)
        }
        
        keyboardView.keyboard = keyboardLayoutManager.getCurrentKeyboard()
        keyboardView.invalidateAllKeys()
    }

    private fun handleEmojiMode() {
        if (isEmojiMode) {
            isEmojiMode = false
            keyboardLayoutManager.setEmojiMode(false)
        } else {
            isEmojiMode = true
            isSymbolsMode = false
            keyboardLayoutManager.setEmojiMode(true)
        }
        
        keyboardView.keyboard = keyboardLayoutManager.getCurrentKeyboard()
        keyboardView.invalidateAllKeys()
    }

    private fun handleEnter(inputConnection: InputConnection) {
        inputConnection.sendKeyEvent(
            KeyEvent(
                KeyEvent.ACTION_DOWN,
                KeyEvent.KEYCODE_ENTER
            )
        )
        inputConnection.sendKeyEvent(
            KeyEvent(
                KeyEvent.ACTION_UP,
                KeyEvent.KEYCODE_ENTER
            )
        )
    }

    private fun handleSecretMode() {
        // فتح نافذة الأسرار
        val intent = android.content.Intent(this, 
            com.keyboard.kyntra.ui.SecretManagementActivity::class.java)
        intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
    }

    private fun openKeyboardSettings() {
        val intent = android.content.Intent(this, 
            com.keyboard.kyntra.ui.SettingsActivity::class.java)
        intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
    }

    private fun loadTextKeyboard() {
        keyboardLayoutManager.setCurrentKeyboardType(KeyboardLayoutManager.KeyboardType.TEXT)
        keyboardView.keyboard = keyboardLayoutManager.getCurrentKeyboard()
    }

    private fun loadPasswordKeyboard() {
        keyboardLayoutManager.setCurrentKeyboardType(KeyboardLayoutManager.KeyboardType.PASSWORD)
        keyboardView.keyboard = keyboardLayoutManager.getCurrentKeyboard()
    }

    private fun loadNumericKeyboard() {
        keyboardLayoutManager.setCurrentKeyboardType(KeyboardLayoutManager.KeyboardType.NUMERIC)
        keyboardView.keyboard = keyboardLayoutManager.getCurrentKeyboard()
    }

    private fun loadPhoneKeyboard() {
        keyboardLayoutManager.setCurrentKeyboardType(KeyboardLayoutManager.KeyboardType.PHONE)
        keyboardView.keyboard = keyboardLayoutManager.getCurrentKeyboard()
    }

    private fun applyCurrentTheme() {
        val themeManager = KeyboardThemeManager.getInstance(this)
        val theme = themeManager.getCurrentTheme()
        
        // تطبيق الألوان على لوحة المفاتيح
        keyboardView.setBackgroundColor(theme.backgroundColor)
        // يمكن إضافة المزيد من تطبيقات السمة هنا
    }

    private fun playClickEffect() {
        if (SharedPrefs.getSoundEnabled(this)) {
            SoundHelper.playKeyClick(this)
        }
    }

    private fun vibrateIfEnabled() {
        if (SharedPrefs.getVibrationEnabled(this)) {
            VibrationHelper.vibrateKeyPress(this)
        }
    }

    override fun swipeRight() {
        // التمرير لليمين لتغيير اللغة
        handleLanguageChange()
    }

    override fun swipeLeft() {
        // التمرير لليسار للتبديل بين الأحرف والرموز
        if (isSymbolsMode) {
            handleSymbols()
        } else {
            handleEmojiMode()
        }
    }

    override fun swipeUp() {
        // لا فعل
    }

    override fun swipeDown() {
        handleClose()
    }

    override fun onPress(primaryCode: Int) {
        // يمكن إضافة تأثيرات الضغط هنا
    }

    override fun onRelease(primaryCode: Int) {
        // يمكن إضافة تأثيرات الإفلات هنا
    }

    override fun onText(text: CharSequence?) {
        // معالجة النص المباشر
        text?.let {
            currentInputConnection?.commitText(it, 1)
        }
    }

    override fun updateShiftKeyState() {
        // تحديث حالة مفتاح shift
        keyboardView.isShifted = capsLock
    }
}