package com.keyboard.kyntra.keyboard

import android.content.Context
import android.content.res.Configuration
import com.keyboard.kyntra.utils.SharedPrefs

data class Language(
    val code: String,
    val name: String,
    val displayName: String,
    val layoutResId: Int,
    val isRTL: Boolean,
    val popupCharacters: Map<Char, String> = emptyMap()
)

class LanguageManager(private val context: Context) {

    companion object {
        const val ENGLISH = "en"
        const val ARABIC = "ar"
        const val FRENCH = "fr"
        const val GERMAN = "de"
        const val SPANISH = "es"
        const val RUSSIAN = "ru"
        const val JAPANESE = "ja"
        const val KOREAN = "ko"
        const val HINDI = "hi"
        const val TURKISH = "tr"
    }

    private val languages = listOf(
        Language(
            code = ENGLISH,
            name = "English",
            displayName = "English",
            layoutResId = R.xml.keyboard_english,
            isRTL = false,
            popupCharacters = mapOf(
                'a' to "á à â ä ã å ā æ",
                'e' to "é è ê ë ē ę ě",
                'i' to "í ì î ï ī į",
                'o' to "ó ò ô ö õ ø ō œ",
                'u' to "ú ù û ü ū ů",
                'c' to "ç ć č",
                'n' to "ñ ń ň",
                's' to "ś š ş",
                'z' to "ż ž ź"
            )
        ),
        Language(
            code = ARABIC,
            name = "العربية",
            displayName = "Arabic",
            layoutResId = R.xml.keyboard_arabic,
            isRTL = true,
            popupCharacters = mapOf(
                'ا' to "أ إ آ ء ئ",
                'ب' to "ة ت ث",
                'ج' to "ح خ",
                'د' to "ذ",
                'ر' to "ز",
                'س' to "ش",
                'ص' to "ض",
                'ط' to "ظ",
                'ع' to "غ",
                'ف' to "ڤ",
                'ق' to "ڨ ڧ",
                'ك' to "ڪ ګ",
                'ل' to "ڵ",
                'ن' to "ڹ ں",
                'ه' to "ۀ ہ ھ",
                'و' to "ؤ",
                'ي' to "ى ئ"
            )
        ),
        Language(
            code = FRENCH,
            name = "Français",
            displayName = "French",
            layoutResId = R.xml.keyboard_french,
            isRTL = false,
            popupCharacters = mapOf(
                'a' to "à â ä",
                'e' to "é è ê ë",
                'i' to "î ï",
                'o' to "ô ö",
                'u' to "ù û ü",
                'c' to "ç",
                'œ' to "Œ",
                'æ' to "Æ"
            )
        ),
        Language(
            code = GERMAN,
            name = "Deutsch",
            displayName = "German",
            layoutResId = R.xml.keyboard_german,
            isRTL = false,
            popupCharacters = mapOf(
                'a' to "ä",
                'o' to "ö",
                'u' to "ü",
                's' to "ß"
            )
        ),
        Language(
            code = SPANISH,
            name = "Español",
            displayName = "Spanish",
            layoutResId = R.xml.keyboard_spanish,
            isRTL = false,
            popupCharacters = mapOf(
                'a' to "á",
                'e' to "é",
                'i' to "í",
                'o' to "ó",
                'u' to "ú ü",
                'n' to "ñ",
                'c' to "ç",
                '¿' to "?",
                '¡' to "!"
            )
        ),
        Language(
            code = RUSSIAN,
            name = "Русский",
            displayName = "Russian",
            layoutResId = R.xml.keyboard_russian,
            isRTL = false,
            popupCharacters = mapOf(
                'а' to "А",
                'б' to "Б",
                'в' to "В",
                'г' to "Г",
                'д' to "Д",
                'е' to "Е Ё",
                'ж' to "Ж",
                'з' to "З",
                'и' to "И",
                'й' to "Й",
                'к' to "К",
                'л' to "Л",
                'м' to "М",
                'н' to "Н",
                'о' to "О",
                'п' to "П",
                'р' to "Р",
                'с' to "С",
                'т' to "Т",
                'у' to "У",
                'ф' to "Ф",
                'х' to "Х",
                'ц' to "Ц",
                'ч' to "Ч",
                'ш' to "Ш",
                'щ' to "Щ",
                'ъ' to "Ъ",
                'ы' to "Ы",
                'ь' to "Ь",
                'э' to "Э",
                'ю' to "Ю",
                'я' to "Я"
            )
        ),
        Language(
            code = JAPANESE,
            name = "日本語",
            displayName = "Japanese",
            layoutResId = R.xml.keyboard_japanese,
            isRTL = false,
            popupCharacters = mapOf(
                'あ' to "ア ぁ",
                'い' to "イ ぃ",
                'う' to "ウ ぅ ヴ",
                'え' to "エ ぇ",
                'お' to "オ ぉ",
                'か' to "カ が",
                'き' to "キ ぎ",
                'く' to "ク ぐ",
                'け' to "ケ げ",
                'こ' to "コ ご",
                'さ' to "サ ざ",
                'し' to "シ じ",
                'す' to "ス ず",
                'せ' to "セ ぜ",
                'そ' to "ソ ぞ",
                'た' to "タ だ",
                'ち' to "チ ぢ",
                'つ' to "ツ づ っ",
                'て' to "テ で",
                'と' to "ト ど",
                'な' to "ナ",
                'に' to "ニ",
                'ぬ' to "ヌ",
                'ね' to "ネ",
                'の' to "ノ",
                'は' to "ハ ば ぱ",
                'ひ' to "ヒ び ぴ",
                'ふ' to "フ ぶ ぷ",
                'へ' to "ヘ べ ぺ",
                'ほ' to "ホ ぼ ぽ",
                'ま' to "マ",
                'み' to "ミ",
                'む' to "ム",
                'め' to "メ",
                'も' to "モ",
                'や' to "ヤ ゃ",
                'ゆ' to "ユ ゅ",
                'よ' to "ヨ ょ",
                'ら' to "ラ",
                'り' to "リ",
                'る' to "ル",
                'れ' to "レ",
                'ろ' to "ロ",
                'わ' to "ワ ゎ",
                'を' to "ヲ",
                'ん' to "ン",
                'ー' to "〜",
                '、' to "。"
            )
        ),
        Language(
            code = KOREAN,
            name = "한국어",
            displayName = "Korean",
            layoutResId = R.xml.keyboard_korean,
            isRTL = false,
            popupCharacters = mapOf(
                'ㅂ' to "ㅃ",
                'ㅈ' to "ㅉ",
                'ㄷ' to "ㄸ",
                'ㄱ' to "ㄲ",
                'ㅅ' to "ㅆ",
                'ㅛ' to "ㅕ ㅑ ㅒ ㅖ",
                'ㅕ' to "ㅛ ㅑ ㅒ ㅖ",
                'ㅑ' to "ㅛ ㅕ ㅒ ㅖ",
                'ㅐ' to "ㅒ",
                'ㅔ' to "ㅖ",
                'ㅁ' to "ㅁ",
                'ㄴ' to "ㄴ",
                'ㅇ' to "ㅇ",
                'ㄹ' to "ㄹ",
                'ㅎ' to "ㅎ",
                'ㅗ' to "ㅗ",
                'ㅓ' to "ㅓ",
                'ㅏ' to "ㅏ",
                'ㅣ' to "ㅣ",
                'ㅋ' to "ㅋ",
                'ㅌ' to "ㅌ",
                'ㅊ' to "ㅊ",
                'ㅍ' to "ㅍ",
                'ㅠ' to "ㅠ",
                'ㅜ' to "ㅜ",
                'ㅡ' to "ㅡ"
            )
        ),
        Language(
            code = HINDI,
            name = "हिन्दी",
            displayName = "Hindi",
            layoutResId = R.xml.keyboard_hindi,
            isRTL = false,
            popupCharacters = mapOf(
                'क' to "ख",
                'ग' to "घ",
                'च' to "छ",
                'ज' to "झ",
                'ट' to "ठ",
                'ड' to "ढ",
                'त' to "थ",
                'द' to "ध",
                'प' to "फ",
                'ब' to "भ",
                'य' to "य",
                'र' to "ऋ",
                'ल' to "ळ",
                'व' to "व",
                'श' to "ष स",
                'ह' to "ह",
                'अ' to "आ",
                'इ' to "ई",
                'उ' to "ऊ",
                'ए' to "ऐ",
                'ओ' to "औ",
                'ं' to "ँ ः"
            )
        ),
        Language(
            code = TURKISH,
            name = "Türkçe",
            displayName = "Turkish",
            layoutResId = R.xml.keyboard_turkish,
            isRTL = false,
            popupCharacters = mapOf(
                'a' to "â",
                'e' to "ë",
                'ı' to "i î",
                'i' to "î",
                'o' to "ö ô",
                'u' to "ü û",
                'g' to "ğ",
                's' to "ş",
                'c' to "ç"
            )
        )
    )

    private var currentLanguageIndex = 0

    init {
        // تحميل اللغة المحفوظة
        val savedLanguageCode = SharedPrefs.getCurrentLanguage(context)
        currentLanguageIndex = languages.indexOfFirst { it.code == savedLanguageCode }
        if (currentLanguageIndex == -1) {
            // استخدام لغة الجهاز إذا لم تكن محفوظة
            val deviceLanguage = getDeviceLanguage()
            currentLanguageIndex = languages.indexOfFirst { it.code == deviceLanguage }
            if (currentLanguageIndex == -1) {
                currentLanguageIndex = 0 // الإنجليزية كافتراضي
            }
        }
    }

    fun getCurrentLanguage(): Language {
        return languages[currentLanguageIndex]
    }

    fun getNextLanguage(): Language {
        currentLanguageIndex = (currentLanguageIndex + 1) % languages.size
        SharedPrefs.setCurrentLanguage(context, getCurrentLanguage().code)
        return getCurrentLanguage()
    }

    fun setLanguage(languageCode: String): Boolean {
        val index = languages.indexOfFirst { it.code == languageCode }
        if (index != -1) {
            currentLanguageIndex = index
            SharedPrefs.setCurrentLanguage(context, languageCode)
            return true
        }
        return false
    }

    fun getAllLanguages(): List<Language> {
        return languages
    }

    fun getLanguageByCode(code: String): Language? {
        return languages.find { it.code == code }
    }

    fun getPopupCharactersForChar(char: Char): String? {
        val currentLang = getCurrentLanguage()
        return currentLang.popupCharacters[char]
    }

    fun getLayoutResId(): Int {
        return getCurrentLanguage().layoutResId
    }

    fun isRTL(): Boolean {
        return getCurrentLanguage().isRTL
    }

    private fun getDeviceLanguage(): String {
        val locale = context.resources.configuration.locales[0]
        return locale.language
    }

    fun shouldUseRTL(): Boolean {
        val config = context.resources.configuration
        return config.layoutDirection == View.LAYOUT_DIRECTION_RTL || isRTL()
    }

    // دعم الأحرف الخاصة عند الضغط المطول
    fun getLongPressCharacters(baseChar: Char): List<Char> {
        val popupString = getPopupCharactersForChar(baseChar)
        return if (popupString != null) {
            popupString.split(" ").map { it.first() }
        } else {
            emptyList()
        }
    }

    // الحصول على اتجاه الكتابة للغة الحالية
    fun getTextDirection(): Int {
        return if (isRTL()) {
            android.view.View.TEXT_DIRECTION_RTL
        } else {
            android.view.View.TEXT_DIRECTION_LTR
        }
    }
}