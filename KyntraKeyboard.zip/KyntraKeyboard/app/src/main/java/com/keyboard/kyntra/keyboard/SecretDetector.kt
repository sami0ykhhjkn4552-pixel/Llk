package com.keyboard.kyntra.keyboard

import android.content.Context
import android.text.TextUtils
import android.util.Log
import com.keyboard.kyntra.KyntraKeyboardApp
import com.keyboard.kyntra.secrets.SecretManager
import java.util.regex.Pattern

class SecretDetector(private val context: Context) {

    companion object {
        private const val TAG = "SecretDetector"
        
        // أنماط اكتشاف الأسرار
        private val SECRET_PATTERNS = listOf(
            Pattern.compile("A(\\d{2,3})"), // A56, A123
            Pattern.compile("B(\\d{2,3})"), // B23, B456
            Pattern.compile("C(\\d{2,3})"), // C89, C789
            Pattern.compile("X(\\d{2,3})"), // X12, X345
            Pattern.compile("P(\\d{2,3})"), // P34, P678
            Pattern.compile("KEY(\\d{2,3})"), // KEY01, KEY99
            Pattern.compile("SEC(\\d{2,3})"), // SEC01, SEC99
            Pattern.compile("PASS(\\d{2,3})"), // PASS01, PASS99
            Pattern.compile("PW(\\d{2,3})"), // PW01, PW99
            Pattern.compile("CODE(\\d{2,3})") // CODE01, CODE99
        )
        
        // أنماط لكلمات المرور الشائعة
        private val PASSWORD_PATTERNS = listOf(
            Pattern.compile(".*@.*\\.(com|org|net|edu|gov|io|co|me|info|biz)"), // إيميلات
            Pattern.compile("\\d{3}-\\d{3}-\\d{4}"), // أرقام هواتف
            Pattern.compile("\\d{4}-\\d{4}-\\d{4}-\\d{4}"), // بطاقات ائتمان
            Pattern.compile("\\d{9,12}"), // أرقام هوية
            Pattern.compile("[A-Za-z0-9]{8,20}") // كلمات مرور عامة
        )
    }

    private val secretManager = SecretManager(context)
    private val inputBuffer = StringBuilder()
    private var lastDetectionTime = 0L
    private val DETECTION_COOLDOWN = 1000L // ثانية واحدة بين الاكتشافات

    /**
     * اكتشاف نمط سري في النص المدخل
     */
    fun detectSecret(input: String): String? {
        // التحقق من وقت التبريد
        val currentTime = System.currentTimeMillis()
        if (currentTime - lastDetectionTime < DETECTION_COOLDOWN) {
            return null
        }

        // إضافة النص إلى المخزن المؤقت
        inputBuffer.append(input)
        
        // الحفاظ على طول معقول للمخزن المؤقت
        if (inputBuffer.length > 100) {
            inputBuffer.delete(0, inputBuffer.length - 100)
        }
        
        val bufferText = inputBuffer.toString()
        
        // البحث عن الأنماط المحددة
        for (pattern in SECRET_PATTERNS) {
            val matcher = pattern.matcher(bufferText)
            if (matcher.find()) {
                val matchedPattern = matcher.group()
                Log.d(TAG, "Pattern detected: $matchedPattern")
                
                // البحث عن السر المطابق
                val secret = secretManager.getSecretByPattern(matchedPattern)
                if (secret != null) {
                    // مسح المخزن المؤقت بعد الاكتشاف الناجح
                    inputBuffer.clear()
                    lastDetectionTime = currentTime
                    return secret
                }
            }
        }
        
        // البحث عن أنماط كلمات المرور العامة
        for (pattern in PASSWORD_PATTERNS) {
            val matcher = pattern.matcher(bufferText)
            if (matcher.find()) {
                val matchedText = matcher.group()
                Log.d(TAG, "Password pattern detected: $matchedText")
                
                // هنا يمكن إضافة منطق للتعامل مع كلمات المرور العامة
                // لكننا لن نخزنها لأسباب أمنية
            }
        }
        
        return null
    }

    /**
     * اكتشاف نمط سري في النص الحالي
     */
    fun detectSecretInCurrentText(currentText: String): String? {
        if (TextUtils.isEmpty(currentText)) {
            return null
        }

        // التحقق من وقت التبريد
        val currentTime = System.currentTimeMillis()
        if (currentTime - lastDetectionTime < DETECTION_COOLDOWN) {
            return null
        }

        // البحث عن الأنماط المحددة
        for (pattern in SECRET_PATTERNS) {
            val matcher = pattern.matcher(currentText)
            if (matcher.find()) {
                val matchedPattern = matcher.group()
                Log.d(TAG, "Pattern detected in current text: $matchedPattern")
                
                // البحث عن السر المطابق
                val secret = secretManager.getSecretByPattern(matchedPattern)
                if (secret != null) {
                    lastDetectionTime = currentTime
                    return secret
                }
            }
        }
        
        return null
    }

    /**
     * التحقق مما إذا كان النص يحتوي على نمط سري
     */
    fun containsSecretPattern(text: String): Boolean {
        if (TextUtils.isEmpty(text)) {
            return false
        }

        for (pattern in SECRET_PATTERNS) {
            val matcher = pattern.matcher(text)
            if (matcher.find()) {
                return true
            }
        }
        
        return false
    }

    /**
     * استخراج النمط السري من النص
     */
    fun extractSecretPattern(text: String): String? {
        if (TextUtils.isEmpty(text)) {
            return null
        }

        for (pattern in SECRET_PATTERNS) {
            val matcher = pattern.matcher(text)
            if (matcher.find()) {
                return matcher.group()
            }
        }
        
        return null
    }

    /**
     * الحصول على جميع الأنماط المعروفة
     */
    fun getAllPatterns(): List<String> {
        return listOf(
            "A56", "A123", "B23", "B456", "C89", "C789",
            "X12", "X345", "P34", "P678", "KEY01", "KEY99",
            "SEC01", "SEC99", "PASS01", "PASS99", "PW01", "PW99",
            "CODE01", "CODE99"
        )
    }

    /**
     * توليد نمط تلقائي بناءً على الوصف
     */
    fun generatePattern(description: String): String {
        val words = description.split(" ")
        val prefix = when {
            description.contains("email", true) -> "EMAIL"
            description.contains("password", true) -> "PASS"
            description.contains("credit", true) -> "CARD"
            description.contains("phone", true) -> "PHONE"
            description.contains("key", true) -> "KEY"
            description.contains("secret", true) -> "SEC"
            words.isNotEmpty() -> words[0].uppercase().take(3)
            else -> "CODE"
        }
        
        // توليد رقم عشوائي مكون من رقمين
        val randomNumber = (1..99).random().toString().padStart(2, '0')
        
        return prefix + randomNumber
    }

    /**
     * التحقق من صحة النمط
     */
    fun isValidPattern(pattern: String): Boolean {
        if (pattern.length < 3 || pattern.length > 10) {
            return false
        }
        
        // يجب أن يبدأ بحروف
        if (!pattern[0].isLetter()) {
            return false
        }
        
        // يجب أن يحتوي على أرقام
        if (!pattern.any { it.isDigit() }) {
            return false
        }
        
        // التحقق من التنسيق
        for (existingPattern in SECRET_PATTERNS) {
            if (existingPattern.pattern().contains(pattern)) {
                return true
            }
        }
        
        return false
    }

    /**
     * مسح المخزن المؤقت
     */
    fun clearBuffer() {
        inputBuffer.clear()
        lastDetectionTime = 0L
    }

    /**
     * الحصول على إحصائيات الاكتشاف
     */
    fun getDetectionStats(): Map<String, Any> {
        return mapOf(
            "buffer_size" to inputBuffer.length,
            "last_detection" to lastDetectionTime,
            "patterns_registered" to SECRET_PATTERNS.size,
            "secrets_available" to secretManager.getAllSecrets().size
        )
    }

    /**
     * تسجيل حدث الاكتشاف (لأغراض التحليل)
     */
    private fun logDetectionEvent(pattern: String, success: Boolean) {
        val eventData = mapOf(
            "timestamp" to System.currentTimeMillis(),
            "pattern" to pattern,
            "success" to success,
            "buffer_length" to inputBuffer.length
        )
        
        // هنا يمكن إرسال البيانات للتحليل (إذا كان مسموحًا بالمستخدم)
        // لكننا لن نفعل ذلك لأسباب خصوصية
        Log.d(TAG, "Detection event: $eventData")
    }

    /**
     * التحقق مما إذا كان النص يحتوي على معلومات حساسة
     */
    fun containsSensitiveInfo(text: String): Boolean {
        if (TextUtils.isEmpty(text)) {
            return false
        }

        // أنماط المعلومات الحساسة
        val sensitivePatterns = listOf(
            Pattern.compile("\\b\\d{3}[.-]?\\d{3}[.-]?\\d{4}\\b"), // أرقام هواتف
            Pattern.compile("\\b\\d{3}[.-]?\\d{2}[.-]?\\d{4}\\b"), // أرقام ضمان اجتماعي
            Pattern.compile("\\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}\\b"), // إيميلات
            Pattern.compile("\\b\\d{4}[.-]?\\d{4}[.-]?\\d{4}[.-]?\\d{4}\\b"), // بطاقات ائتمان
            Pattern.compile("\\b\\d{9,12}\\b") // أرقام هوية
        )

        for (pattern in sensitivePatterns) {
            val matcher = pattern.matcher(text)
            if (matcher.find()) {
                return true
            }
        }
        
        return false
    }

    /**
     * استبدال المعلومات الحساسة بنص آمن
     */
    fun sanitizeText(text: String): String {
        var sanitized = text
        
        // أنماط الاستبدال
        val replacementPatterns = mapOf(
            Pattern.compile("\\b\\d{3}[.-]?\\d{3}[.-]?\\d{4}\\b") to "[PHONE]", // أرقام هواتف
            Pattern.compile("\\b\\d{3}[.-]?\\d{2}[.-]?\\d{4}\\b") to "[SSN]", // أرقام ضمان اجتماعي
            Pattern.compile("\\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}\\b") to "[EMAIL]", // إيميلات
            Pattern.compile("\\b\\d{4}[.-]?\\d{4}[.-]?\\d{4}[.-]?\\d{4}\\b") to "[CARD]", // بطاقات ائتمان
            Pattern.compile("\\b\\d{9,12}\\b") to "[ID]" // أرقام هوية
        )

        replacementPatterns.forEach { (pattern, replacement) ->
            val matcher = pattern.matcher(sanitized)
            sanitized = matcher.replaceAll(replacement)
        }
        
        return sanitized
    }
}