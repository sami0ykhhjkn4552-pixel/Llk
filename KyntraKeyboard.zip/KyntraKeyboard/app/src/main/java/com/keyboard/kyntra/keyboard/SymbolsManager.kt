package com.keyboard.kyntra.keyboard

import android.content.Context
import com.keyboard.kyntra.R
import com.keyboard.kyntra.utils.SharedPrefs

data class SymbolCategory(
    val name: String,
    val symbols: List<Symbol>,
    val iconResId: Int = 0
)

data class Symbol(
    val display: String,
    val code: Int,
    val description: String = "",
    val category: String = "",
    val isProgramming: Boolean = false
)

class SymbolsManager(private val context: Context) {

    companion object {
        // فئات الرموز
        const val CATEGORY_PROGRAMMING = "programming"
        const val CATEGORY_MATH = "math"
        const val CATEGORY_CURRENCY = "currency"
        const val CATEGORY_ARROWS = "arrows"
        const val CATEGORY_BRACKETS = "brackets"
        const val CATEGORY_SPECIAL = "special"
        const val CATEGORY_PUNCTUATION = "punctuation"
    }

    private val symbolCategories = listOf(
        SymbolCategory(
            name = CATEGORY_PROGRAMMING,
            symbols = listOf(
                Symbol("{", 123, "Opening Curly Brace", CATEGORY_PROGRAMMING, true),
                Symbol("}", 125, "Closing Curly Brace", CATEGORY_PROGRAMMING, true),
                Symbol("[", 91, "Opening Square Bracket", CATEGORY_PROGRAMMING, true),
                Symbol("]", 93, "Closing Square Bracket", CATEGORY_PROGRAMMING, true),
                Symbol("(", 40, "Opening Parenthesis", CATEGORY_PROGRAMMING, true),
                Symbol(")", 41, "Closing Parenthesis", CATEGORY_PROGRAMMING, true),
                Symbol("<", 60, "Less Than", CATEGORY_PROGRAMMING, true),
                Symbol(">", 62, "Greater Than", CATEGORY_PROGRAMMING, true),
                Symbol("=", 61, "Equals", CATEGORY_PROGRAMMING, true),
                Symbol("!", 33, "Exclamation Mark", CATEGORY_PROGRAMMING, true),
                Symbol("@", 64, "At Symbol", CATEGORY_PROGRAMMING, true),
                Symbol("#", 35, "Hash/Pound", CATEGORY_PROGRAMMING, true),
                Symbol("$", 36, "Dollar Sign", CATEGORY_PROGRAMMING, true),
                Symbol("%", 37, "Percent", CATEGORY_PROGRAMMING, true),
                Symbol("^", 94, "Caret", CATEGORY_PROGRAMMING, true),
                Symbol("&", 38, "Ampersand", CATEGORY_PROGRAMMING, true),
                Symbol("*", 42, "Asterisk", CATEGORY_PROGRAMMING, true),
                Symbol("|", 124, "Pipe/Vertical Bar", CATEGORY_PROGRAMMING, true),
                Symbol("\\", 92, "Backslash", CATEGORY_PROGRAMMING, true),
                Symbol("/", 47, "Forward Slash", CATEGORY_PROGRAMMING, true),
                Symbol("~", 126, "Tilde", CATEGORY_PROGRAMMING, true),
                Symbol("`", 96, "Backtick/Grave", CATEGORY_PROGRAMMING, true),
                Symbol(";", 59, "Semicolon", CATEGORY_PROGRAMMING, true),
                Symbol(":", 58, "Colon", CATEGORY_PROGRAMMING, true),
                Symbol("\"", 34, "Double Quote", CATEGORY_PROGRAMMING, true),
                Symbol("'", 39, "Single Quote", CATEGORY_PROGRAMMING, true),
                Symbol("_", 95, "Underscore", CATEGORY_PROGRAMMING, true),
                Symbol("-", 45, "Hyphen/Dash", CATEGORY_PROGRAMMING, true),
                Symbol("+", 43, "Plus", CATEGORY_PROGRAMMING, true)
            ),
            iconResId = R.drawable.ic_code
        ),
        SymbolCategory(
            name = CATEGORY_MATH,
            symbols = listOf(
                Symbol("±", 177, "Plus-Minus", CATEGORY_MATH),
                Symbol("×", 215, "Multiplication", CATEGORY_MATH),
                Symbol("÷", 247, "Division", CATEGORY_MATH),
                Symbol("√", 8730, "Square Root", CATEGORY_MATH),
                Symbol("∞", 8734, "Infinity", CATEGORY_MATH),
                Symbol("≈", 8776, "Approximately Equal", CATEGORY_MATH),
                Symbol("≠", 8800, "Not Equal", CATEGORY_MATH),
                Symbol("≤", 8804, "Less Than or Equal", CATEGORY_MATH),
                Symbol("≥", 8805, "Greater Than or Equal", CATEGORY_MATH),
                Symbol("∑", 8721, "Summation", CATEGORY_MATH),
                Symbol("∏", 8719, "Product", CATEGORY_MATH),
                Symbol("∫", 8747, "Integral", CATEGORY_MATH),
                Symbol("∂", 8706, "Partial Differential", CATEGORY_MATH),
                Symbol("∆", 8710, "Increment", CATEGORY_MATH),
                Symbol("∇", 8711, "Nabla", CATEGORY_MATH),
                Symbol("∈", 8712, "Element Of", CATEGORY_MATH),
                Symbol("∉", 8713, "Not Element Of", CATEGORY_MATH),
                Symbol("∩", 8745, "Intersection", CATEGORY_MATH),
                Symbol("∪", 8746, "Union", CATEGORY_MATH),
                Symbol("⊂", 8834, "Subset Of", CATEGORY_MATH),
                Symbol("⊃", 8835, "Superset Of", CATEGORY_MATH),
                Symbol("∧", 8743, "Logical And", CATEGORY_MATH),
                Symbol("∨", 8744, "Logical Or", CATEGORY_MATH),
                Symbol("¬", 172, "Logical Not", CATEGORY_MATH),
                Symbol("∀", 8704, "For All", CATEGORY_MATH),
                Symbol("∃", 8707, "There Exists", CATEGORY_MATH),
                Symbol("∅", 8709, "Empty Set", CATEGORY_MATH),
                Symbol("∠", 8736, "Angle", CATEGORY_MATH),
                Symbol("°", 176, "Degree", CATEGORY_MATH),
                Symbol("π", 960, "Pi", CATEGORY_MATH)
            ),
            iconResId = R.drawable.ic_math
        ),
        SymbolCategory(
            name = CATEGORY_CURRENCY,
            symbols = listOf(
                Symbol("€", 8364, "Euro", CATEGORY_CURRENCY),
                Symbol("£", 163, "Pound Sterling", CATEGORY_CURRENCY),
                Symbol("¥", 165, "Yen/Yuan", CATEGORY_CURRENCY),
                Symbol("₹", 8377, "Indian Rupee", CATEGORY_CURRENCY),
                Symbol("₽", 8381, "Russian Ruble", CATEGORY_CURRENCY),
                Symbol("₩", 8361, "Korean Won", CATEGORY_CURRENCY),
                Symbol("₺", 8378, "Turkish Lira", CATEGORY_CURRENCY),
                Symbol("₴", 8372, "Ukrainian Hryvnia", CATEGORY_CURRENCY),
                Symbol("₿", 8383, "Bitcoin", CATEGORY_CURRENCY),
                Symbol("¢", 162, "Cent", CATEGORY_CURRENCY),
                Symbol("¤", 164, "Currency Sign", CATEGORY_CURRENCY),
                Symbol("ƒ", 402, "Florin", CATEGORY_CURRENCY),
                Symbol("₣", 8355, "French Franc", CATEGORY_CURRENCY),
                Symbol("₤", 8356, "Lira", CATEGORY_CURRENCY),
                Symbol("₲", 8370, "Guarani", CATEGORY_CURRENCY),
                Symbol("₵", 8373, "Cedi", CATEGORY_CURRENCY),
                Symbol("₪", 8362, "Shekel", CATEGORY_CURRENCY),
                Symbol("₫", 8363, "Dong", CATEGORY_CURRENCY),
                Symbol("₭", 8365, "Kip", CATEGORY_CURRENCY),
                Symbol("₮", 8366, "Tugrik", CATEGORY_CURRENCY)
            ),
            iconResId = R.drawable.ic_currency
        ),
        SymbolCategory(
            name = CATEGORY_ARROWS,
            symbols = listOf(
                Symbol("←", 8592, "Left Arrow", CATEGORY_ARROWS),
                Symbol("→", 8594, "Right Arrow", CATEGORY_ARROWS),
                Symbol("↑", 8593, "Up Arrow", CATEGORY_ARROWS),
                Symbol("↓", 8595, "Down Arrow", CATEGORY_ARROWS),
                Symbol("↔", 8596, "Left-Right Arrow", CATEGORY_ARROWS),
                Symbol("↕", 8597, "Up-Down Arrow", CATEGORY_ARROWS),
                Symbol("↖", 8598, "North West Arrow", CATEGORY_ARROWS),
                Symbol("↗", 8599, "North East Arrow", CATEGORY_ARROWS),
                Symbol("↘", 8600, "South East Arrow", CATEGORY_ARROWS),
                Symbol("↙", 8601, "South West Arrow", CATEGORY_ARROWS),
                Symbol("⇐", 8656, "Left Double Arrow", CATEGORY_ARROWS),
                Symbol("⇒", 8658, "Right Double Arrow", CATEGORY_ARROWS),
                Symbol("⇑", 8657, "Up Double Arrow", CATEGORY_ARROWS),
                Symbol("⇓", 8659, "Down Double Arrow", CATEGORY_ARROWS),
                Symbol("⇔", 8660, "Left-Right Double Arrow", CATEGORY_ARROWS),
                Symbol("⇕", 8661, "Up-Down Double Arrow", CATEGORY_ARROWS),
                Symbol("↩", 8617, "Leftwards Arrow with Hook", CATEGORY_ARROWS),
                Symbol("↪", 8618, "Rightwards Arrow with Hook", CATEGORY_ARROWS),
                Symbol("↶", 8630, "Anticlockwise Top Semicircle Arrow", CATEGORY_ARROWS),
                Symbol("↷", 8631, "Clockwise Top Semicircle Arrow", CATEGORY_ARROWS)
            ),
            iconResId = R.drawable.ic_arrow
        ),
        SymbolCategory(
            name = CATEGORY_BRACKETS,
            symbols = listOf(
                Symbol("⟨", 9001, "Left Angle Bracket", CATEGORY_BRACKETS),
                Symbol("⟩", 9002, "Right Angle Bracket", CATEGORY_BRACKETS),
                Symbol("⟪", 10218, "Mathematical Left Double Angle Bracket", CATEGORY_BRACKETS),
                Symbol("⟫", 10219, "Mathematical Right Double Angle Bracket", CATEGORY_BRACKETS),
                Symbol("⌈", 8968, "Left Ceiling", CATEGORY_BRACKETS),
                Symbol("⌉", 8969, "Right Ceiling", CATEGORY_BRACKETS),
                Symbol("⌊", 8970, "Left Floor", CATEGORY_BRACKETS),
                Symbol("⌋", 8971, "Right Floor", CATEGORY_BRACKETS),
                Symbol("〈", 9001, "Left-Pointing Angle Bracket", CATEGORY_BRACKETS),
                Symbol("〉", 9002, "Right-Pointing Angle Bracket", CATEGORY_BRACKETS),
                Symbol("❨", 10088, "Medium Left Parenthesis Ornament", CATEGORY_BRACKETS),
                Symbol("❩", 10089, "Medium Right Parenthesis Ornament", CATEGORY_BRACKETS),
                Symbol("❪", 10090, "Medium Flattened Left Parenthesis Ornament", CATEGORY_BRACKETS),
                Symbol("❫", 10091, "Medium Flattened Right Parenthesis Ornament", CATEGORY_BRACKETS),
                Symbol("❬", 10092, "Medium Left-Pointing Angle Bracket Ornament", CATEGORY_BRACKETS),
                Symbol("❭", 10093, "Medium Right-Pointing Angle Bracket Ornament", CATEGORY_BRACKETS),
                Symbol("❮", 10094, "Heavy Left-Pointing Angle Quotation Mark Ornament", CATEGORY_BRACKETS),
                Symbol("❯", 10095, "Heavy Right-Pointing Angle Quotation Mark Ornament", CATEGORY_BRACKETS),
                Symbol("❰", 10096, "Heavy Left-Pointing Angle Bracket Ornament", CATEGORY_BRACKETS),
                Symbol("❱", 10097, "Heavy Right-Pointing Angle Bracket Ornament", CATEGORY_BRACKETS)
            ),
            iconResId = R.drawable.ic_brackets
        ),
        SymbolCategory(
            name = CATEGORY_SPECIAL,
            symbols = listOf(
                Symbol("©", 169, "Copyright", CATEGORY_SPECIAL),
                Symbol("®", 174, "Registered Trademark", CATEGORY_SPECIAL),
                Symbol("™", 8482, "Trademark", CATEGORY_SPECIAL),
                Symbol("§", 167, "Section", CATEGORY_SPECIAL),
                Symbol("¶", 182, "Pilcrow/Paragraph", CATEGORY_SPECIAL),
                Symbol("†", 8224, "Dagger", CATEGORY_SPECIAL),
                Symbol("‡", 8225, "Double Dagger", CATEGORY_SPECIAL),
                Symbol("•", 8226, "Bullet", CATEGORY_SPECIAL),
                Symbol("○", 9675, "Circle", CATEGORY_SPECIAL),
                Symbol("●", 9679, "Black Circle", CATEGORY_SPECIAL),
                Symbol("□", 9633, "White Square", CATEGORY_SPECIAL),
                Symbol("■", 9632, "Black Square", CATEGORY_SPECIAL),
                Symbol("▲", 9650, "Black Up-Pointing Triangle", CATEGORY_SPECIAL),
                Symbol("▼", 9660, "Black Down-Pointing Triangle", CATEGORY_SPECIAL),
                Symbol("◆", 9670, "Black Diamond", CATEGORY_SPECIAL),
                Symbol("◇", 9671, "White Diamond", CATEGORY_SPECIAL),
                Symbol("★", 9733, "Black Star", CATEGORY_SPECIAL),
                Symbol("☆", 9734, "White Star", CATEGORY_SPECIAL),
                Symbol("♠", 9824, "Spade Suit", CATEGORY_SPECIAL),
                Symbol("♣", 9827, "Club Suit", CATEGORY_SPECIAL),
                Symbol("♥", 9829, "Heart Suit", CATEGORY_SPECIAL),
                Symbol("♦", 9830, "Diamond Suit", CATEGORY_SPECIAL)
            ),
            iconResId = R.drawable.ic_special
        ),
        SymbolCategory(
            name = CATEGORY_PUNCTUATION,
            symbols = listOf(
                Symbol("…", 8230, "Ellipsis", CATEGORY_PUNCTUATION),
                Symbol("·", 183, "Middle Dot", CATEGORY_PUNCTUATION),
                Symbol("‿", 8255, "Undertie", CATEGORY_PUNCTUATION),
                Symbol("⁀", 8256, "Character Tie", CATEGORY_PUNCTUATION),
                Symbol("‸", 8248, "Care", CATEGORY_PUNCTUATION),
                Symbol("⁇", 8263, "Double Question Mark", CATEGORY_PUNCTUATION),
                Symbol("⁈", 8264, "Question Exclamation Mark", CATEGORY_PUNCTUATION),
                Symbol("⁉", 8265, "Exclamation Question Mark", CATEGORY_PUNCTUATION),
                Symbol("‼", 8252, "Double Exclamation Mark", CATEGORY_PUNCTUATION),
                Symbol("※", 8251, "Reference Mark", CATEGORY_PUNCTUATION),
                Symbol("⸮", 11822, "Reversed Question Mark", CATEGORY_PUNCTUATION),
                Symbol("⸘", 11800, "Reversed Interrobang", CATEGORY_PUNCTUATION),
                Symbol("⁂", 8258, "Asterism", CATEGORY_PUNCTUATION),
                Symbol("❡", 10081, "Leaf Paragraph Ornament", CATEGORY_PUNCTUATION),
                Symbol("❢", 10082, "Leaf Ornament", CATEGORY_PUNCTUATION),
                Symbol("❣", 10083, "Heavy Heart Exclamation Mark Ornament", CATEGORY_PUNCTUATION),
                Symbol("⁑", 8273, "Two Asterisks Aligned Vertically", CATEGORY_PUNCTUATION),
                Symbol("⁒", 8274, "Commercial Minus Sign", CATEGORY_PUNCTUATION),
                Symbol("⁓", 8275, "Swung Dash", CATEGORY_PUNCTUATION),
                Symbol("⁔", 8276, "Inverted Undertie", CATEGORY_PUNCTUATION)
            ),
            iconResId = R.drawable.ic_punctuation
        )
    )

    private var currentCategoryIndex = 0
    private var favoriteSymbols = mutableSetOf<String>()

    init {
        loadFavoriteSymbols()
    }

    fun getCurrentCategory(): SymbolCategory {
        return symbolCategories[currentCategoryIndex]
    }

    fun getNextCategory(): SymbolCategory {
        currentCategoryIndex = (currentCategoryIndex + 1) % symbolCategories.size
        return getCurrentCategory()
    }

    fun getPreviousCategory(): SymbolCategory {
        currentCategoryIndex = (currentCategoryIndex - 1 + symbolCategories.size) % symbolCategories.size
        return getCurrentCategory()
    }

    fun setCategory(categoryName: String): Boolean {
        val index = symbolCategories.indexOfFirst { it.name == categoryName }
        if (index != -1) {
            currentCategoryIndex = index
            return true
        }
        return false
    }

    fun getAllCategories(): List<SymbolCategory> {
        return symbolCategories
    }

    fun getCategoryByName(name: String): SymbolCategory? {
        return symbolCategories.find { it.name == name }
    }

    fun getProgrammingSymbols(): List<Symbol> {
        return symbolCategories.find { it.name == CATEGORY_PROGRAMMING }?.symbols ?: emptyList()
    }

    fun searchSymbols(query: String): List<Symbol> {
        val searchQuery = query.lowercase()
        return symbolCategories.flatMap { it.symbols }
            .filter { symbol ->
                symbol.display.lowercase().contains(searchQuery) ||
                symbol.description.lowercase().contains(searchQuery) ||
                symbol.category.lowercase().contains(searchQuery)
            }
    }

    fun addToFavorites(symbol: Symbol) {
        favoriteSymbols.add(symbol.display)
        saveFavoriteSymbols()
    }

    fun removeFromFavorites(symbol: Symbol) {
        favoriteSymbols.remove(symbol.display)
        saveFavoriteSymbols()
    }

    fun isFavorite(symbol: Symbol): Boolean {
        return favoriteSymbols.contains(symbol.display)
    }

    fun getFavoriteSymbols(): List<Symbol> {
        val allSymbols = symbolCategories.flatMap { it.symbols }
        return allSymbols.filter { favoriteSymbols.contains(it.display) }
    }

    private fun loadFavoriteSymbols() {
        val favoritesJson = SharedPrefs.getFavoriteSymbols(context)
        if (favoritesJson.isNotEmpty()) {
            try {
                val listType = object : com.google.gson.reflect.TypeToken<List<String>>() {}.type
                val favorites = com.google.gson.Gson().fromJson<List<String>>(favoritesJson, listType)
                favoriteSymbols.addAll(favorites)
            } catch (e: Exception) {
                // تجاهل الخطأ واستخدام القائمة الفارغة
            }
        }
    }

    private fun saveFavoriteSymbols() {
        val favoritesJson = com.google.gson.Gson().toJson(favoriteSymbols.toList())
        SharedPrefs.setFavoriteSymbols(context, favoritesJson)
    }

    fun getSymbolByCode(code: Int): Symbol? {
        return symbolCategories.flatMap { it.symbols }.find { it.code == code }
    }

    fun getSymbolByDisplay(display: String): Symbol? {
        return symbolCategories.flatMap { it.symbols }.find { it.display == display }
    }

    // الحصول على الرموز الأكثر استخدامًا
    fun getMostUsedSymbols(limit: Int = 20): List<Symbol> {
        val usageCount = SharedPrefs.getSymbolUsageCount(context)
        return symbolCategories.flatMap { it.symbols }
            .sortedByDescending { usageCount[it.display] ?: 0 }
            .take(limit)
    }

    // تسجيل استخدام رمز
    fun recordSymbolUsage(symbol: Symbol) {
        val usageCount = SharedPrefs.getSymbolUsageCount(context).toMutableMap()
        val currentCount = usageCount[symbol.display] ?: 0
        usageCount[symbol.display] = currentCount + 1
        SharedPrefs.setSymbolUsageCount(context, usageCount)
    }

    // الحصول على الرموز المقترحة بناءً على السياق
    fun getContextualSuggestions(contextText: String): List<Symbol> {
        val suggestions = mutableListOf<Symbol>()
        val programmingKeywords = listOf("if", "for", "while", "function", "class", "import", "export")
        
        programmingKeywords.forEach { keyword ->
            if (contextText.contains(keyword)) {
                when (keyword) {
                    "if", "for", "while" -> {
                        suggestions.addAll(getProgrammingSymbols().filter { 
                            it.display == "(" || it.display == ")" || it.display == "{" || it.display == "}" 
                        })
                    }
                    "function", "class" -> {
                        suggestions.addAll(getProgrammingSymbols().filter { 
                            it.display == "(" || it.display == ")" || it.display == "{" || it.display == "}" 
                        })
                    }
                    "import", "export" -> {
                        suggestions.addAll(getProgrammingSymbols().filter { 
                            it.display == ";" 
                        })
                    }
                }
            }
        }
        
        return suggestions.distinctBy { it.display }
    }
}