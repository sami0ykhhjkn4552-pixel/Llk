package com.keyboard.kyntra.models

import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Parcelize
data class SecretItem(
    val id: Long = 0,
    val pattern: String,
    val description: String,
    val category: String = "general",
    val createdAt: Long = System.currentTimeMillis(),
    val lastUsed: Long = System.currentTimeMillis(),
    val useCount: Int = 0,
    val isFavorite: Boolean = false,
    val requiresBiometric: Boolean = false
) : Parcelable {
    
    val formattedCreatedAt: String
        get() = formatDate(createdAt)
    
    val formattedLastUsed: String
        get() = formatDate(lastUsed)
    
    val usageFrequency: String
        get() = when {
            useCount == 0 -> "Never used"
            useCount < 5 -> "Rarely used"
            useCount < 20 -> "Sometimes used"
            else -> "Frequently used"
        }
    
    val categoryIcon: Int
        get() = when (category.lowercase()) {
            "email" -> R.drawable.ic_email
            "password" -> R.drawable.ic_password
            "credit_card" -> R.drawable.ic_credit_card
            "phone" -> R.drawable.ic_phone
            "address" -> R.drawable.ic_address
            "bank" -> R.drawable.ic_bank
            "social" -> R.drawable.ic_social
            "work" -> R.drawable.ic_work
            "personal" -> R.drawable.ic_personal
            else -> R.drawable.ic_secret
        }
    
    val categoryColor: Int
        get() = when (category.lowercase()) {
            "email" -> R.color.category_email
            "password" -> R.color.category_password
            "credit_card" -> R.color.category_credit_card
            "phone" -> R.color.category_phone
            "address" -> R.color.category_address
            "bank" -> R.color.category_bank
            "social" -> R.color.category_social
            "work" -> R.color.category_work
            "personal" -> R.color.category_personal
            else -> R.color.category_general
        }
    
    private fun formatDate(timestamp: Long): String {
        return try {
            val date = Date(timestamp)
            val now = Date()
            val diff = now.time - timestamp
            
            when {
                diff < 60000 -> "Just now" // أقل من دقيقة
                diff < 3600000 -> "${diff / 60000} min ago" // أقل من ساعة
                diff < 86400000 -> "${diff / 3600000} hours ago" // أقل من يوم
                diff < 604800000 -> "${diff / 86400000} days ago" // أقل من أسبوع
                else -> {
                    val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
                    sdf.format(date)
                }
            }
        } catch (e: Exception) {
            "Unknown"
        }
    }
    
    fun getSecurityLevel(): SecurityLevel {
        return when {
            requiresBiometric -> SecurityLevel.HIGH
            pattern.length >= 8 && pattern.matches(Regex(".*[A-Z].*")) &&
            pattern.matches(Regex(".*[0-9].*")) -> SecurityLevel.MEDIUM
            else -> SecurityLevel.LOW
        }
    }
    
    enum class SecurityLevel {
        LOW, MEDIUM, HIGH
    }
    
    companion object {
        val CATEGORIES = listOf(
            "general", "email", "password", "credit_card", 
            "phone", "address", "bank", "social", "work", "personal"
        )
        
        fun getCategoryDisplayName(category: String): String {
            return when (category.lowercase()) {
                "email" -> "Email"
                "password" -> "Password"
                "credit_card" -> "Credit Card"
                "phone" -> "Phone"
                "address" -> "Address"
                "bank" -> "Bank"
                "social" -> "Social"
                "work" -> "Work"
                "personal" -> "Personal"
                else -> "General"
            }
        }
        
        fun validatePattern(pattern: String): ValidationResult {
            return when {
                pattern.isEmpty() -> ValidationResult(false, "Pattern cannot be empty")
                pattern.length < 3 -> ValidationResult(false, "Pattern must be at least 3 characters")
                pattern.length > 20 -> ValidationResult(false, "Pattern must be at most 20 characters")
                !pattern.matches(Regex("^[A-Za-z0-9]+$")) -> 
                    ValidationResult(false, "Pattern can only contain letters and numbers")
                else -> ValidationResult(true, "Valid pattern")
            }
        }
        
        data class ValidationResult(val isValid: Boolean, val message: String)
    }
}