package com.keyboard.kyntra.keyboard

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.security.crypto.EncryptedFile
import androidx.security.crypto.MasterKeys
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

class EncryptionUtils(private val context: Context) {
    
    companion object {
        private const val KEY_ALIAS = "KyntraKeyboard_Key"
        private const val KEYSTORE_PROVIDER = "AndroidKeyStore"
        private const val TRANSFORMATION = "AES/GCM/NoPadding"
        private const val IV_LENGTH = 12 // GCM recommends 12 bytes IV
        private const val TAG_LENGTH = 128 // GCM tag length in bits
        
        // تهيئة المفتاح عند أول استخدام
        @Volatile
        private var isKeyInitialized = false
        
        private fun initializeKeyIfNeeded() {
            if (!isKeyInitialized) {
                synchronized(this) {
                    if (!isKeyInitialized) {
                        try {
                            val keyStore = KeyStore.getInstance(KEYSTORE_PROVIDER)
                            keyStore.load(null)
                            
                            if (!keyStore.containsAlias(KEY_ALIAS)) {
                                val keyGenParameterSpec = KeyGenParameterSpec.Builder(
                                    KEY_ALIAS,
                                    KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
                                )
                                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                                    .setKeySize(256)
                                    .setUserAuthenticationRequired(false)
                                    .build()
                                
                                val keyGenerator = KeyGenerator.getInstance(
                                    KeyProperties.KEY_ALGORITHM_AES,
                                    KEYSTORE_PROVIDER
                                )
                                keyGenerator.init(keyGenParameterSpec)
                                keyGenerator.generateKey()
                            }
                            
                            isKeyInitialized = true
                        } catch (e: Exception) {
                            throw RuntimeException("Failed to initialize encryption key", e)
                        }
                    }
                }
            }
        }
    }
    
    private val keyStore: KeyStore by lazy {
        initializeKeyIfNeeded()
        KeyStore.getInstance(KEYSTORE_PROVIDER).apply {
            load(null)
        }
    }
    
    private val secretKey: SecretKey by lazy {
        val entry = keyStore.getEntry(KEY_ALIAS, null) as KeyStore.SecretKeyEntry
        entry.secretKey
    }
    
    /**
     * تشفير النص
     */
    fun encrypt(plaintext: String): String {
        return try {
            val cipher = Cipher.getInstance(TRANSFORMATION)
            
            // توليد IV عشوائي
            val iv = ByteArray(IV_LENGTH).apply {
                java.security.SecureRandom().nextBytes(this)
            }
            
            cipher.init(Cipher.ENCRYPT_MODE, secretKey, GCMParameterSpec(TAG_LENGTH, iv))
            
            val ciphertext = cipher.doFinal(plaintext.toByteArray(StandardCharsets.UTF_8))
            
            // دمج IV مع النص المشفر
            val combined = ByteArray(iv.size + ciphertext.size)
            System.arraycopy(iv, 0, combined, 0, iv.size)
            System.arraycopy(ciphertext, 0, combined, iv.size, ciphertext.size)
            
            // ترميز base64 للإرجاع
            Base64.encodeToString(combined, Base64.NO_WRAP)
        } catch (e: Exception) {
            // في حالة الفشل، إرجاع النص كما هو (لأغراض التصحيح فقط)
            // في الإصدار النهائي، يجب التعامل مع الخطأ بشكل أفضل
            "ERROR:${Base64.encodeToString(plaintext.toByteArray(), Base64.NO_WRAP)}"
        }
    }
    
    /**
     * فك تشفير النص
     */
    fun decrypt(encryptedText: String): String? {
        return try {
            if (encryptedText.startsWith("ERROR:")) {
                // هذا نص غير مشفر (للتصحيح فقط)
                val base64Data = encryptedText.removePrefix("ERROR:")
                return String(Base64.decode(base64Data, Base64.NO_WRAP), StandardCharsets.UTF_8)
            }
            
            val combined = Base64.decode(encryptedText, Base64.NO_WRAP)
            
            if (combined.size < IV_LENGTH) {
                return null
            }
            
            val iv = combined.copyOfRange(0, IV_LENGTH)
            val ciphertext = combined.copyOfRange(IV_LENGTH, combined.size)
            
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.DECRYPT_MODE, secretKey, GCMParameterSpec(TAG_LENGTH, iv))
            
            val plaintext = cipher.doFinal(ciphertext)
            String(plaintext, StandardCharsets.UTF_8)
        } catch (e: Exception) {
            null
        }
    }
    
    /**
     * تشفير الملفات
     */
    fun encryptFile(plaintext: String, fileName: String): Boolean {
        return try {
            val masterKeyAlias = MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC)
            
            val encryptedFile = EncryptedFile.Builder(
                context.getFileStreamPath(fileName),
                context,
                masterKeyAlias,
                EncryptedFile.FileEncryptionScheme.AES256_GCM_HKDF_4KB
            ).build()
            
            encryptedFile.openFileOutput().use { outputStream ->
                outputStream.write(plaintext.toByteArray(StandardCharsets.UTF_8))
            }
            
            true
        } catch (e: Exception) {
            false
        }
    }
    
    /**
     * فك تشفير الملفات
     */
    fun decryptFile(fileName: String): String? {
        return try {
            val masterKeyAlias = MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC)
            
            val encryptedFile = EncryptedFile.Builder(
                context.getFileStreamPath(fileName),
                context,
                masterKeyAlias,
                EncryptedFile.FileEncryptionScheme.AES256_GCM_HKDF_4KB
            ).build()
            
            encryptedFile.openFileInput().use { inputStream ->
                val bytes = inputStream.readBytes()
                String(bytes, StandardCharsets.UTF_8)
            }
        } catch (e: Exception) {
            null
        }
    }
    
    /**
     * تشفير البيانات الثنائية
     */
    fun encryptBytes(data: ByteArray): ByteArray? {
        return try {
            val cipher = Cipher.getInstance(TRANSFORMATION)
            val iv = ByteArray(IV_LENGTH).apply {
                java.security.SecureRandom().nextBytes(this)
            }
            
            cipher.init(Cipher.ENCRYPT_MODE, secretKey, GCMParameterSpec(TAG_LENGTH, iv))
            val encryptedData = cipher.doFinal(data)
            
            val combined = ByteArray(iv.size + encryptedData.size)
            System.arraycopy(iv, 0, combined, 0, iv.size)
            System.arraycopy(encryptedData, 0, combined, iv.size, encryptedData.size)
            
            combined
        } catch (e: Exception) {
            null
        }
    }
    
    /**
     * فك تشفير البيانات الثنائية
     */
    fun decryptBytes(encryptedData: ByteArray): ByteArray? {
        return try {
            if (encryptedData.size < IV_LENGTH) {
                return null
            }
            
            val iv = encryptedData.copyOfRange(0, IV_LENGTH)
            val ciphertext = encryptedData.copyOfRange(IV_LENGTH, encryptedData.size)
            
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.DECRYPT_MODE, secretKey, GCMParameterSpec(TAG_LENGTH, iv))
            
            cipher.doFinal(ciphertext)
        } catch (e: Exception) {
            null
        }
    }
    
    /**
     * التحقق من صحة النص المشفر
     */
    fun isValidEncryptedText(text: String): Boolean {
        return try {
            if (text.startsWith("ERROR:")) {
                val base64Data = text.removePrefix("ERROR:")
                Base64.decode(base64Data, Base64.NO_WRAP)
                true
            } else {
                val decoded = Base64.decode(text, Base64.NO_WRAP)
                decoded.size >= IV_LENGTH
            }
        } catch (e: Exception) {
            false
        }
    }
    
    /**
     * توليد مفتاح جديد (للاستخدام في حالات خاصة)
     */
    fun regenerateKey(): Boolean {
        return try {
            synchronized(this) {
                // حذف المفتاح القديم
                if (keyStore.containsAlias(KEY_ALIAS)) {
                    keyStore.deleteEntry(KEY_ALIAS)
                }
                
                // توليد مفتاح جديد
                val keyGenParameterSpec = KeyGenParameterSpec.Builder(
                    KEY_ALIAS,
                    KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
                )
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256)
                    .setUserAuthenticationRequired(false)
                    .build()
                
                val keyGenerator = KeyGenerator.getInstance(
                    KeyProperties.KEY_ALGORITHM_AES,
                    KEYSTORE_PROVIDER
                )
                keyGenerator.init(keyGenParameterSpec)
                keyGenerator.generateKey()
                
                true
            }
        } catch (e: Exception) {
            false
        }
    }
    
    /**
     * التحقق من وجود المفتاح
     */
    fun isKeyAvailable(): Boolean {
        return try {
            keyStore.containsAlias(KEY_ALIAS)
        } catch (e: Exception) {
            false
        }
    }
    
    /**
     * تشفير باستخدام كلمة مرور مؤقتة (للاستخدام في حالات الطوارئ)
     */
    fun encryptWithPassword(plaintext: String, password: String): String {
        return try {
            // توليد مفتاح من كلمة المرور
            val salt = ByteArray(16).apply {
                java.security.SecureRandom().nextBytes(this)
            }
            
            val spec = javax.crypto.spec.PBEKeySpec(
                password.toCharArray(),
                salt,
                65536,
                256
            )
            
            val factory = javax.crypto.SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            val secretKey = factory.generateSecret(spec)
            
            val cipher = Cipher.getInstance(TRANSFORMATION)
            val iv = ByteArray(IV_LENGTH).apply {
                java.security.SecureRandom().nextBytes(this)
            }
            
            val keySpec = javax.crypto.spec.SecretKeySpec(secretKey.encoded, "AES")
            cipher.init(Cipher.ENCRYPT_MODE, keySpec, GCMParameterSpec(TAG_LENGTH, iv))
            
            val ciphertext = cipher.doFinal(plaintext.toByteArray(StandardCharsets.UTF_8))
            
            // دمج الملح و IV والنص المشفر
            val combined = ByteArray(salt.size + iv.size + ciphertext.size)
            System.arraycopy(salt, 0, combined, 0, salt.size)
            System.arraycopy(iv, 0, combined, salt.size, iv.size)
            System.arraycopy(ciphertext, 0, combined, salt.size + iv.size, ciphertext.size)
            
            Base64.encodeToString(combined, Base64.NO_WRAP)
        } catch (e: Exception) {
            "ERROR:${Base64.encodeToString(plaintext.toByteArray(), Base64.NO_WRAP)}"
        }
    }
    
    /**
     * فك تشفير باستخدام كلمة مرور
     */
    fun decryptWithPassword(encryptedText: String, password: String): String? {
        return try {
            if (encryptedText.startsWith("ERROR:")) {
                val base64Data = encryptedText.removePrefix("ERROR:")
                return String(Base64.decode(base64Data, Base64.NO_WRAP), StandardCharsets.UTF_8)
            }
            
            val combined = Base64.decode(encryptedText, Base64.NO_WRAP)
            
            if (combined.size < 16 + IV_LENGTH) {
                return null
            }
            
            val salt = combined.copyOfRange(0, 16)
            val iv = combined.copyOfRange(16, 16 + IV_LENGTH)
            val ciphertext = combined.copyOfRange(16 + IV_LENGTH, combined.size)
            
            val spec = javax.crypto.spec.PBEKeySpec(
                password.toCharArray(),
                salt,
                65536,
                256
            )
            
            val factory = javax.crypto.SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            val secretKey = factory.generateSecret(spec)
            
            val cipher = Cipher.getInstance(TRANSFORMATION)
            val keySpec = javax.crypto.spec.SecretKeySpec(secretKey.encoded, "AES")
            cipher.init(Cipher.DECRYPT_MODE, keySpec, GCMParameterSpec(TAG_LENGTH, iv))
            
            val plaintext = cipher.doFinal(ciphertext)
            String(plaintext, StandardCharsets.UTF_8)
        } catch (e: Exception) {
            null
        }
    }
    
    /**
     * تنظيف البيانات الحساسة من الذاكرة
     */
    fun cleanSensitiveData(data: CharArray) {
        java.util.Arrays.fill(data, '\u0000')
    }
    
    /**
     * توليد مفتاح عشوائي آمن
     */
    fun generateSecureRandomKey(length: Int = 32): String {
        val bytes = ByteArray(length)
        java.security.SecureRandom().nextBytes(bytes)
        return Base64.encodeToString(bytes, Base64.NO_WRAP)
    }
}