package com.keyboard.kyntra.secrets

import android.content.Context
import androidx.room.*
import com.keyboard.kyntra.KyntraKeyboardApp
import com.keyboard.kyntra.keyboard.EncryptionUtils
import com.keyboard.kyntra.models.SecretItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Entity(tableName = "secrets")
data class SecretEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    
    @ColumnInfo(name = "pattern")
    val pattern: String,
    
    @ColumnInfo(name = "encrypted_data")
    val encryptedData: String,
    
    @ColumnInfo(name = "description")
    val description: String,
    
    @ColumnInfo(name = "category")
    val category: String,
    
    @ColumnInfo(name = "created_at")
    val createdAt: Long = System.currentTimeMillis(),
    
    @ColumnInfo(name = "last_used")
    val lastUsed: Long = System.currentTimeMillis(),
    
    @ColumnInfo(name = "use_count")
    val useCount: Int = 0,
    
    @ColumnInfo(name = "is_favorite")
    val isFavorite: Boolean = false,
    
    @ColumnInfo(name = "requires_biometric")
    val requiresBiometric: Boolean = false
)

data class SecretDTO(
    val pattern: String,
    val data: String,
    val description: String,
    val category: String = "general",
    val requiresBiometric: Boolean = false
)

@Dao
interface SecretDao {
    @Query("SELECT * FROM secrets ORDER BY last_used DESC")
    suspend fun getAll(): List<SecretEntity>
    
    @Query("SELECT * FROM secrets WHERE pattern = :pattern LIMIT 1")
    suspend fun getByPattern(pattern: String): SecretEntity?
    
    @Query("SELECT * FROM secrets WHERE category = :category ORDER BY last_used DESC")
    suspend fun getByCategory(category: String): List<SecretEntity>
    
    @Query("SELECT * FROM secrets WHERE is_favorite = 1 ORDER BY last_used DESC")
    suspend fun getFavorites(): List<SecretEntity>
    
    @Query("SELECT * FROM secrets WHERE description LIKE '%' || :query || '%' OR pattern LIKE '%' || :query || '%'")
    suspend fun search(query: String): List<SecretEntity>
    
    @Insert
    suspend fun insert(secret: SecretEntity): Long
    
    @Update
    suspend fun update(secret: SecretEntity)
    
    @Delete
    suspend fun delete(secret: SecretEntity)
    
    @Query("DELETE FROM secrets WHERE pattern = :pattern")
    suspend fun deleteByPattern(pattern: String)
    
    @Query("UPDATE secrets SET last_used = :timestamp, use_count = use_count + 1 WHERE id = :id")
    suspend fun recordUsage(id: Long, timestamp: Long)
    
    @Query("SELECT COUNT(*) FROM secrets")
    suspend fun getCount(): Int
}

@Database(
    entities = [SecretEntity::class],
    version = 1,
    exportSchema = false
)
abstract class SecretDatabase : RoomDatabase() {
    abstract fun secretDao(): SecretDao
    
    companion object {
        const val DATABASE_NAME = "secrets.db"
    }
}

class SecretManager(private val context: Context) {
    
    private val encryptionUtils = EncryptionUtils(context)
    private val secretDao = KyntraKeyboardApp.secretDatabase.secretDao()
    
    /**
     * إضافة سر جديد
     */
    suspend fun addSecret(dto: SecretDTO): Result<Long> = withContext(Dispatchers.IO) {
        return@withContext try {
            // التحقق من عدم وجود النمط مسبقًا
            val existing = secretDao.getByPattern(dto.pattern)
            if (existing != null) {
                return@withContext Result.failure(Exception("Pattern already exists"))
            }
            
            // تشفير البيانات
            val encryptedData = encryptionUtils.encrypt(dto.data)
            
            val entity = SecretEntity(
                pattern = dto.pattern,
                encryptedData = encryptedData,
                description = dto.description,
                category = dto.category,
                requiresBiometric = dto.requiresBiometric
            )
            
            val id = secretDao.insert(entity)
            Result.success(id)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    /**
     * الحصول على سر بواسطة النمط
     */
    suspend fun getSecretByPattern(pattern: String): String? = withContext(Dispatchers.IO) {
        return@withContext try {
            val entity = secretDao.getByPattern(pattern)
            if (entity != null) {
                // تسجيل الاستخدام
                secretDao.recordUsage(entity.id, System.currentTimeMillis())
                
                // فك التشفير وإرجاع البيانات
                encryptionUtils.decrypt(entity.encryptedData)
            } else {
                null
            }
        } catch (e: Exception) {
            null
        }
    }
    
    /**
     * الحصول على جميع الأسرار
     */
    suspend fun getAllSecrets(): List<SecretItem> = withContext(Dispatchers.IO) {
        return@withContext try {
            val entities = secretDao.getAll()
            entities.map { entity ->
                SecretItem(
                    id = entity.id,
                    pattern = entity.pattern,
                    description = entity.description,
                    category = entity.category,
                    createdAt = entity.createdAt,
                    lastUsed = entity.lastUsed,
                    useCount = entity.useCount,
                    isFavorite = entity.isFavorite,
                    requiresBiometric = entity.requiresBiometric
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }
    
    /**
     * تحديث سر موجود
     */
    suspend fun updateSecret(id: Long, dto: SecretDTO): Result<Unit> = withContext(Dispatchers.IO) {
        return@withContext try {
            val entity = secretDao.getByPattern(dto.pattern)
            if (entity != null && entity.id != id) {
                return@withContext Result.failure(Exception("Pattern already exists"))
            }
            
            // تشفير البيانات الجديدة
            val encryptedData = encryptionUtils.encrypt(dto.data)
            
            val updatedEntity = SecretEntity(
                id = id,
                pattern = dto.pattern,
                encryptedData = encryptedData,
                description = dto.description,
                category = dto.category,
                createdAt = System.currentTimeMillis(),
                lastUsed = System.currentTimeMillis(),
                useCount = 0,
                isFavorite = false,
                requiresBiometric = dto.requiresBiometric
            )
            
            secretDao.update(updatedEntity)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    /**
     * حذف سر
     */
    suspend fun deleteSecret(id: Long): Result<Unit> = withContext(Dispatchers.IO) {
        return@withContext try {
            val secrets = secretDao.getAll()
            val entity = secrets.find { it.id == id }
            if (entity != null) {
                secretDao.delete(entity)
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    /**
     * حذف سر بواسطة النمط
     */
    suspend fun deleteSecretByPattern(pattern: String): Result<Unit> = withContext(Dispatchers.IO) {
        return@withContext try {
            secretDao.deleteByPattern(pattern)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    /**
     * البحث في الأسرار
     */
    suspend fun searchSecrets(query: String): List<SecretItem> = withContext(Dispatchers.IO) {
        return@withContext try {
            val entities = secretDao.search(query)
            entities.map { entity ->
                SecretItem(
                    id = entity.id,
                    pattern = entity.pattern,
                    description = entity.description,
                    category = entity.category,
                    createdAt = entity.createdAt,
                    lastUsed = entity.lastUsed,
                    useCount = entity.useCount,
                    isFavorite = entity.isFavorite,
                    requiresBiometric = entity.requiresBiometric
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }
    
    /**
     * الحصول على الأسرار حسب الفئة
     */
    suspend fun getSecretsByCategory(category: String): List<SecretItem> = withContext(Dispatchers.IO) {
        return@withContext try {
            val entities = secretDao.getByCategory(category)
            entities.map { entity ->
                SecretItem(
                    id = entity.id,
                    pattern = entity.pattern,
                    description = entity.description,
                    category = entity.category,
                    createdAt = entity.createdAt,
                    lastUsed = entity.lastUsed,
                    useCount = entity.useCount,
                    isFavorite = entity.isFavorite,
                    requiresBiometric = entity.requiresBiometric
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }
    
    /**
     * تبديل حالة المفضلة
     */
    suspend fun toggleFavorite(id: Long): Result<Boolean> = withContext(Dispatchers.IO) {
        return@withContext try {
            val secrets = secretDao.getAll()
            val entity = secrets.find { it.id == id }
            if (entity != null) {
                val updatedEntity = entity.copy(
                    isFavorite = !entity.isFavorite
                )
                secretDao.update(updatedEntity)
                Result.success(updatedEntity.isFavorite)
            } else {
                Result.failure(Exception("Secret not found"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    /**
     * الحصول على الأسرار المفضلة
     */
    suspend fun getFavoriteSecrets(): List<SecretItem> = withContext(Dispatchers.IO) {
        return@withContext try {
            val entities = secretDao.getFavorites()
            entities.map { entity ->
                SecretItem(
                    id = entity.id,
                    pattern = entity.pattern,
                    description = entity.description,
                    category = entity.category,
                    createdAt = entity.createdAt,
                    lastUsed = entity.lastUsed,
                    useCount = entity.useCount,
                    isFavorite = entity.isFavorite,
                    requiresBiometric = entity.requiresBiometric
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }
    
    /**
     * التحقق من وجود نمط
     */
    suspend fun patternExists(pattern: String): Boolean = withContext(Dispatchers.IO) {
        return@withContext try {
            val entity = secretDao.getByPattern(pattern)
            entity != null
        } catch (e: Exception) {
            false
        }
    }
    
    /**
     * الحصول على إحصائيات الأسرار
     */
    suspend fun getStats(): Map<String, Any> = withContext(Dispatchers.IO) {
        return@withContext try {
            val total = secretDao.getCount()
            val favorites = secretDao.getFavorites().size
            val categories = secretDao.getAll().groupBy { it.category }.keys.size
            
            mapOf(
                "total" to total,
                "favorites" to favorites,
                "categories" to categories
            )
        } catch (e: Exception) {
            emptyMap()
        }
    }
    
    /**
     * تصدير جميع الأسرار (مشفرة)
     */
    suspend fun exportSecrets(): String = withContext(Dispatchers.IO) {
        return@withContext try {
            val entities = secretDao.getAll()
            val exportData = entities.map { entity ->
                mapOf(
                    "pattern" to entity.pattern,
                    "encryptedData" to entity.encryptedData,
                    "description" to entity.description,
                    "category" to entity.category,
                    "createdAt" to entity.createdAt,
                    "requiresBiometric" to entity.requiresBiometric
                )
            }
            
            com.google.gson.Gson().toJson(exportData)
        } catch (e: Exception) {
            ""
        }
    }
    
    /**
     * استيراد الأسرار
     */
    suspend fun importSecrets(jsonData: String): Result<Int> = withContext(Dispatchers.IO) {
        return@withContext try {
            val type = object : com.google.gson.reflect.TypeToken<List<Map<String, Any>>>() {}.type
            val importList = com.google.gson.Gson().fromJson<List<Map<String, Any>>>(jsonData, type)
            
            var importedCount = 0
            importList.forEach { item ->
                val pattern = item["pattern"] as? String ?: ""
                val encryptedData = item["encryptedData"] as? String ?: ""
                val description = item["description"] as? String ?: ""
                val category = item["category"] as? String ?: "general"
                val requiresBiometric = item["requiresBiometric"] as? Boolean ?: false
                
                // التحقق من عدم وجود النمط مسبقًا
                val exists = secretDao.getByPattern(pattern)
                if (exists == null && pattern.isNotEmpty() && encryptedData.isNotEmpty()) {
                    val entity = SecretEntity(
                        pattern = pattern,
                        encryptedData = encryptedData,
                        description = description,
                        category = category,
                        requiresBiometric = requiresBiometric
                    )
                    secretDao.insert(entity)
                    importedCount++
                }
            }
            
            Result.success(importedCount)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    /**
     * مسح جميع الأسرار
     */
    suspend fun clearAllSecrets(): Result<Unit> = withContext(Dispatchers.IO) {
        return@withContext try {
            val entities = secretDao.getAll()
            entities.forEach { entity ->
                secretDao.delete(entity)
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    /**
     * التحقق من صحة السر
     */
    fun validateSecret(dto: SecretDTO): ValidationResult {
        return when {
            dto.pattern.isEmpty() -> ValidationResult(false, "Pattern cannot be empty")
            dto.pattern.length < 3 -> ValidationResult(false, "Pattern must be at least 3 characters")
            dto.pattern.length > 20 -> ValidationResult(false, "Pattern must be at most 20 characters")
            !dto.pattern.matches(Regex("^[A-Za-z0-9]+$")) -> ValidationResult(false, "Pattern can only contain letters and numbers")
            dto.data.isEmpty() -> ValidationResult(false, "Data cannot be empty")
            dto.data.length > 1000 -> ValidationResult(false, "Data is too long")
            dto.description.isEmpty() -> ValidationResult(false, "Description cannot be empty")
            dto.description.length > 100 -> ValidationResult(false, "Description is too long")
            else -> ValidationResult(true, "Valid")
        }
    }
    
    data class ValidationResult(val isValid: Boolean, val message: String)
}