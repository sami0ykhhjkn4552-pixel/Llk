package com.keyboard.kyntra.ui

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.keyboard.kyntra.R
import com.keyboard.kyntra.databinding.ActivityMainBinding
import com.keyboard.kyntra.keyboard.KeyboardThemeManager
import com.keyboard.kyntra.utils.SharedPrefs

class MainActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityMainBinding
    private lateinit var themeManager: KeyboardThemeManager
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // تطبيق السمة
        applyTheme()
        
        // إعداد واجهة المستخدم
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        // تهيئة مدير السمة
        themeManager = KeyboardThemeManager.getInstance(this)
        
        // إعداد النافذة
        setupWindow()
        
        // إعداد واجهة المستخدم
        setupUI()
        
        // إعداد المستمعين للأحداث
        setupListeners()
        
        // التحقق من إذن لوحة المفاتيح
        checkKeyboardPermission()
    }
    
    private fun applyTheme() {
        val themeMode = SharedPrefs.getThemeMode(this)
        when (themeMode) {
            "dark" -> setTheme(R.style.Theme_KyntraKeyboard_Dark)
            "light" -> setTheme(R.style.Theme_KyntraKeyboard_Light)
            "high_contrast" -> setTheme(R.style.Theme_KyntraKeyboard_HighContrast)
            else -> setTheme(R.style.Theme_KyntraKeyboard)
        }
    }
    
    private fun setupWindow() {
        // شفافية الحالة
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        window.statusBarColor = ContextCompat.getColor(this, android.R.color.transparent)
        window.navigationBarColor = ContextCompat.getColor(this, android.R.color.transparent)
        
        // شريط التنقل الشفاف
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            window.isNavigationBarContrastEnforced = false
        }
        
        // شريط الحالة الشفاف
        WindowCompat.setDecorFitsSystemWindows(window, false)
        
        // التحكم في أشرطة النظام
        WindowInsetsControllerCompat(window, window.decorView).let { controller ->
            controller.hide(WindowInsetsCompat.Type.systemBars())
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }
    
    private fun setupUI() {
        // تطبيق السمة الحالية
        val currentTheme = themeManager.getCurrentTheme()
        
        // خلفية النشاط
        binding.root.setBackgroundColor(currentTheme.backgroundColor)
        
        // إعداد الأزرار
        setupButtons()
        
        // إعداد البطاقات
        setupCards()
        
        // تحديث الإحصائيات
        updateStatistics()
    }
    
    private fun setupButtons() {
        val theme = themeManager.getCurrentTheme()
        
        // زر تفعيل لوحة المفاتيح
        binding.btnEnableKeyboard.background = themeManager.generateKeyGradient(theme)
        binding.btnEnableKeyboard.setTextColor(theme.keyTextColor)
        
        // زر إدارة الأسرار
        binding.btnManageSecrets.background = themeManager.generateKeyGradient(theme)
        binding.btnManageSecrets.setTextColor(theme.keyTextColor)
        
        // زر الإعدادات
        binding.btnSettings.background = themeManager.generateKeyGradient(theme)
        binding.btnSettings.setTextColor(theme.keyTextColor)
        
        // زر حول التطبيق
        binding.btnAbout.background = themeManager.generateKeyGradient(theme)
        binding.btnAbout.setTextColor(theme.keyTextColor)
        
        // زر المساعدة
        binding.btnHelp.background = themeManager.generateKeyGradient(theme)
        binding.btnHelp.setTextColor(theme.keyTextColor)
    }
    
    private fun setupCards() {
        val theme = themeManager.getCurrentTheme()
        
        // بطاقة الإحصائيات
        binding.cardStats.background = themeManager.createKeyShadow(theme)
        binding.cardStats.setCardBackgroundColor(theme.keyBackgroundColor)
        
        // بطاقة الحالة
        binding.cardStatus.background = themeManager.createKeyShadow(theme)
        binding.cardStatus.setCardBackgroundColor(theme.keyBackgroundColor)
        
        // بطاقة التحديثات
        binding.cardUpdates.background = themeManager.createKeyShadow(theme)
        binding.cardUpdates.setCardBackgroundColor(theme.keyBackgroundColor)
    }
    
    private fun setupListeners() {
        // زر تفعيل لوحة المفاتيح
        binding.btnEnableKeyboard.setOnClickListener {
            openKeyboardSettings()
        }
        
        // زر إدارة الأسرار
        binding.btnManageSecrets.setOnClickListener {
            startActivity(Intent(this, SecretManagementActivity::class.java))
        }
        
        // زر الإعدادات
        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        
        // زر حول التطبيق
        binding.btnAbout.setOnClickListener {
            showAboutDialog()
        }
        
        // زر المساعدة
        binding.btnHelp.setOnClickListener {
            showHelpDialog()
        }
        
        // زر تحديث الإحصائيات
        binding.btnRefreshStats.setOnClickListener {
            updateStatistics()
        }
        
        // زر تغيير السمة
        binding.btnChangeTheme.setOnClickListener {
            changeTheme()
        }
        
        // زر التحديثات
        binding.btnCheckUpdates.setOnClickListener {
            checkForUpdates()
        }
    }
    
    private fun checkKeyboardPermission() {
        // التحقق من إذن لوحة المفاتيح
        val isEnabled = isInputMethodEnabled()
        
        if (!isEnabled) {
            binding.tvKeyboardStatus.text = getString(R.string.keyboard_disabled)
            binding.tvKeyboardStatus.setTextColor(
                ContextCompat.getColor(this, R.color.error_red)
            )
            binding.btnEnableKeyboard.visibility = View.VISIBLE
        } else {
            binding.tvKeyboardStatus.text = getString(R.string.keyboard_enabled)
            binding.tvKeyboardStatus.setTextColor(
                ContextCompat.getColor(this, R.color.success_green)
            )
            binding.btnEnableKeyboard.visibility = View.GONE
        }
    }
    
    private fun isInputMethodEnabled(): Boolean {
        val imeId = packageName + "/" + com.keyboard.kyntra.keyboard.KyntraKeyboardService::class.java.name
        val enabledImeIds = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_INPUT_METHODS
        )
        
        return enabledImeIds?.contains(imeId) ?: false
    }
    
    private fun openKeyboardSettings() {
        try {
            val intent = Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)
            startActivity(intent)
        } catch (e: Exception) {
            // فتح إعدادات النظام العامة
            val intent = Intent(Settings.ACTION_SETTINGS)
            startActivity(intent)
        }
    }
    
    private fun updateStatistics() {
        val stats = SharedPrefs.getAllStats(this)
        
        binding.tvTotalTyped.text = stats["total_typed"]?.toString() ?: "0"
        binding.tvTotalWords.text = stats["total_words"]?.toString() ?: "0"
        binding.tvTotalEmojis.text = stats["total_emojis"]?.toString() ?: "0"
        binding.tvTotalSymbols.text = stats["total_symbols"]?.toString() ?: "0"
        binding.tvTotalSecrets.text = stats["total_secrets"]?.toString() ?: "0"
        
        // تحديث الوقت
        val lastUpdate = SharedPrefs.getLastUpdateCheck(this)
        if (lastUpdate > 0) {
            val sdf = java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", java.util.Locale.getDefault())
            binding.tvLastUpdate.text = sdf.format(java.util.Date(lastUpdate))
        }
    }
    
    private fun changeTheme() {
        val currentTheme = themeManager.getCurrentTheme()
        val nextTheme = themeManager.getNextTheme(currentTheme.name)
        
        themeManager.setTheme(nextTheme.name)
        recreate() // إعادة إنشاء النشاط لتطبيق السمة الجديدة
    }
    
    private fun checkForUpdates() {
        // هنا يمكن إضافة منطق التحقق من التحديثات
        binding.tvUpdateStatus.text = getString(R.string.checking_updates)
        
        // محاكاة التحقق من التحديثات
        binding.btnCheckUpdates.postDelayed({
            binding.tvUpdateStatus.text = getString(R.string.no_updates_available)
        }, 1500)
    }
    
    private fun showAboutDialog() {
        val dialog = androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(getString(R.string.about_app))
            .setMessage(getString(R.string.about_message))
            .setPositiveButton(getString(R.string.ok), null)
            .setNeutralButton(getString(R.string.visit_website)) { _, _ ->
                openWebsite()
            }
            .create()
        
        dialog.show()
    }
    
    private fun showHelpDialog() {
        val dialog = androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(getString(R.string.help))
            .setMessage(getString(R.string.help_message))
            .setPositiveButton(getString(R.string.ok), null)
            .setNeutralButton(getString(R.string.contact_support)) { _, _ ->
                contactSupport()
            }
            .create()
        
        dialog.show()
    }
    
    private fun openWebsite() {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://kyntrakeyboard.com"))
            startActivity(intent)
        } catch (e: Exception) {
            // تجاهل الخطأ
        }
    }
    
    private fun contactSupport() {
        try {
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("mailto:support@kyntrakeyboard.com")
                putExtra(Intent.EXTRA_SUBJECT, "Kyntra Keyboard Support")
            }
            startActivity(intent)
        } catch (e: Exception) {
            // تجاهل الخطأ
        }
    }
    
    override fun onResume() {
        super.onResume()
        // التحقق من إذن لوحة المفاتيح عند العودة
        checkKeyboardPermission()
        // تحديث الإحصائيات
        updateStatistics()
    }
    
    override fun onBackPressed() {
        // إغلاق التطبيق عند الضغط على زر الرجوع
        finishAffinity()
    }
}