package com.keyboard.kyntra.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.preference.*
import com.keyboard.kyntra.R
import com.keyboard.kyntra.keyboard.KeyboardThemeManager
import com.keyboard.kyntra.utils.SharedPrefs

class SettingsActivity : AppCompatActivity() {
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // تحميل إعدادات السمة
        loadTheme()
        
        // عرض إعدادات الشاشة
        supportFragmentManager
            .beginTransaction()
            .replace(android.R.id.content, SettingsFragment())
            .commit()
        
        // إعداد شريط الأدوات
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = getString(R.string.settings)
    }
    
    private fun loadTheme() {
        val themeMode = SharedPrefs.getThemeMode(this)
        when (themeMode) {
            "dark" -> setTheme(R.style.Theme_KyntraKeyboard_Dark)
            "light" -> setTheme(R.style.Theme_KyntraKeyboard_Light)
            "high_contrast" -> setTheme(R.style.Theme_KyntraKeyboard_HighContrast)
            else -> setTheme(R.style.Theme_KyntraKeyboard)
        }
    }
    
    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
    
    class SettingsFragment : PreferenceFragmentCompat() {
        
        private lateinit var themeManager: KeyboardThemeManager
        
        override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
            setPreferencesFromResource(R.xml.settings_preferences, rootKey)
            
            // تهيئة مدير السمة
            themeManager = KeyboardThemeManager.getInstance(requireContext())
            
            // إعداد المستمعين
            setupListeners()
            
            // تحديث الملخصات
            updateSummaries()
        }
        
        private fun setupListeners() {
            // سمة التطبيق
            findPreference<DropDownPreference>("theme_mode")?.setOnPreferenceChangeListener { _, newValue ->
                val theme = newValue.toString()
                themeManager.setTheme(theme)
                requireActivity().recreate()
                true
            }
            
            // اللغة
            findPreference<DropDownPreference>("language")?.setOnPreferenceChangeListener { _, newValue ->
                val language = newValue.toString()
                SharedPrefs.setCurrentLanguage(requireContext(), language)
                true
            }
            
            // الصوت
            findPreference<SwitchPreferenceCompat>("sound_enabled")?.setOnPreferenceChangeListener { _, newValue ->
                val enabled = newValue as Boolean
                SharedPrefs.setSoundEnabled(requireContext(), enabled)
                true
            }
            
            // الاهتزاز
            findPreference<SwitchPreferenceCompat>("vibration_enabled")?.setOnPreferenceChangeListener { _, newValue ->
                val enabled = newValue as Boolean
                SharedPrefs.setVibrationEnabled(requireContext(), enabled)
                true
            }
            
            // قوة الاهتزاز
            findPreference<SeekBarPreference>("vibration_strength")?.setOnPreferenceChangeListener { _, newValue ->
                val strength = newValue as Int
                SharedPrefs.setVibrationStrength(requireContext(), strength)
                true
            }
            
            // تصفية الإيموجيات
            findPreference<SwitchPreferenceCompat>("emoji_filter_enabled")?.setOnPreferenceChangeListener { _, newValue ->
                val enabled = newValue as Boolean
                SharedPrefs.setEmojiFilterEnabled(requireContext(), enabled)
                true
            }
            
            // تصفية الكلمات البذيئة
            findPreference<SwitchPreferenceCompat>("word_filter_enabled")?.setOnPreferenceChangeListener { _, newValue ->
                val enabled = newValue as Boolean
                SharedPrefs.setWordFilterEnabled(requireContext(), enabled)
                true
            }
            
            // إشعارات اللصق
            findPreference<SwitchPreferenceCompat>("show_paste_notification")?.setOnPreferenceChangeListener { _, newValue ->
                val enabled = newValue as Boolean
                SharedPrefs.setShowPasteNotification(requireContext(), enabled)
                true
            }
            
            // إخفاء كلمات المرور
            findPreference<SwitchPreferenceCompat>("mask_passwords")?.setOnPreferenceChangeListener { _, newValue ->
                val enabled = newValue as Boolean
                SharedPrefs.setMaskPasswords(requireContext(), enabled)
                true
            }
            
            // تصحيح تلقائي
            findPreference<SwitchPreferenceCompat>("auto_correct_enabled")?.setOnPreferenceChangeListener { _, newValue ->
                val enabled = newValue as Boolean
                SharedPrefs.setAutoCorrectEnabled(requireContext(), enabled)
                true
            }
            
            // نص تنبؤي
            findPreference<SwitchPreferenceCompat>("predictive_text_enabled")?.setOnPreferenceChangeListener { _, newValue ->
                val enabled = newValue as Boolean
                SharedPrefs.setPredictiveTextEnabled(requireContext(), enabled)
                true
            }
            
            // ارتفاع لوحة المفاتيح
            findPreference<SeekBarPreference>("keyboard_height")?.setOnPreferenceChangeListener { _, newValue ->
                val height = newValue as Int
                SharedPrefs.setKeyboardHeight(requireContext(), height)
                true
            }
            
            // شفافية لوحة المفاتيح
            findPreference<SeekBarPreference>("keyboard_transparency")?.setOnPreferenceChangeListener { _, newValue ->
                val transparency = newValue as Int
                SharedPrefs.setKeyboardTransparency(requireContext(), transparency)
                true
            }
            
            // إعدادات لوحة المفاتيح
            findPreference<Preference>("keyboard_settings")?.setOnPreferenceClickListener {
                openKeyboardSettings()
                true
            }
            
            // مسح البيانات
            findPreference<Preference>("clear_data")?.setOnPreferenceClickListener {
                showClearDataDialog()
                true
            }
            
            // سياسة الخصوصية
            findPreference<Preference>("privacy_policy")?.setOnPreferenceClickListener {
                openPrivacyPolicy()
                true
            }
            
            // شروط الخدمة
            findPreference<Preference>("terms_of_service")?.setOnPreferenceClickListener {
                openTermsOfService()
                true
            }
            
            // حول التطبيق
            findPreference<Preference>("about_app")?.setOnPreferenceClickListener {
                openAboutApp()
                true
            }
            
            // المساعدة والدعم
            findPreference<Preference>("help_support")?.setOnPreferenceClickListener {
                openHelpSupport()
                true
            }
            
            // تقييم التطبيق
            findPreference<Preference>("rate_app")?.setOnPreferenceClickListener {
                rateApp()
                true
            }
            
            // مشاركة التطبيق
            findPreference<Preference>("share_app")?.setOnPreferenceClickListener {
                shareApp()
                true
            }
        }
        
        private fun updateSummaries() {
            // تحديث ملخص السمة
            val themePref = findPreference<DropDownPreference>("theme_mode")
            val currentTheme = themeManager.getCurrentTheme()
            themePref?.summary = when (currentTheme.name) {
                "dark" -> "Dark Theme"
                "light" -> "Light Theme"
                "high_contrast" -> "High Contrast"
                else -> "System Default"
            }
            
            // تحديث ملخص اللغة
            val languagePref = findPreference<DropDownPreference>("language")
            val currentLanguage = SharedPrefs.getCurrentLanguage(requireContext())
            languagePref?.summary = when (currentLanguage) {
                "en" -> "English"
                "ar" -> "العربية"
                "fr" -> "Français"
                "de" -> "Deutsch"
                "es" -> "Español"
                "ru" -> "Русский"
                "ja" -> "日本語"
                "ko" -> "한국어"
                "hi" -> "हिन्दी"
                "tr" -> "Türkçe"
                else -> "English"
            }
            
            // تحديث ملخص قوة الاهتزاز
            val vibrationPref = findPreference<SeekBarPreference>("vibration_strength")
            val vibrationStrength = SharedPrefs.getVibrationStrength(requireContext())
            vibrationPref?.summary = "$vibrationStrength%"
            
            // تحديث ملخص ارتفاع لوحة المفاتيح
            val heightPref = findPreference<SeekBarPreference>("keyboard_height")
            val keyboardHeight = SharedPrefs.getKeyboardHeight(requireContext())
            heightPref?.summary = "$keyboardHeight%"
            
            // تحديث ملخص الشفافية
            val transparencyPref = findPreference<SeekBarPreference>("keyboard_transparency")
            val transparency = SharedPrefs.getKeyboardTransparency(requireContext())
            transparencyPref?.summary = "$transparency%"
            
            // تحديث إصدار التطبيق
            val versionPref = findPreference<Preference>("app_version")
            try {
                val packageInfo = requireContext().packageManager.getPackageInfo(
                    requireContext().packageName,
                    0
                )
                versionPref?.summary = packageInfo.versionName
            } catch (e: Exception) {
                versionPref?.summary = "Unknown"
            }
        }
        
        private fun openKeyboardSettings() {
            try {
                val intent = Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)
                startActivity(intent)
            } catch (e: Exception) {
                val intent = Intent(Settings.ACTION_SETTINGS)
                startActivity(intent)
            }
        }
        
        private fun showClearDataDialog() {
            androidx.appcompat.app.AlertDialog.Builder(requireContext())
                .setTitle("Clear All Data")
                .setMessage("This will delete all your secrets, settings, and statistics. This action cannot be undone.")
                .setPositiveButton("Clear") { dialog, _ ->
                    clearAllData()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        
        private fun clearAllData() {
            SharedPrefs.clearAll(requireContext())
            showMessage("All data has been cleared")
            updateSummaries()
        }
        
        private fun openPrivacyPolicy() {
            openUrl("https://kyntrakeyboard.com/privacy")
        }
        
        private fun openTermsOfService() {
            openUrl("https://kyntrakeyboard.com/terms")
        }
        
        private fun openAboutApp() {
            val intent = Intent(requireContext(), MainActivity::class.java)
            intent.putExtra("show_about", true)
            startActivity(intent)
        }
        
        private fun openHelpSupport() {
            openUrl("https://kyntrakeyboard.com/support")
        }
        
        private fun rateApp() {
            try {
                val packageName = requireContext().packageName
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    data = Uri.parse("market://details?id=$packageName")
                }
                startActivity(intent)
            } catch (e: Exception) {
                val packageName = requireContext().packageName
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    data = Uri.parse("https://play.google.com/store/apps/details?id=$packageName")
                }
                startActivity(intent)
            }
        }
        
        private fun shareApp() {
            val shareText = "Check out Kyntra Keyboard - The ultimate keyboard for programmers!"
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, shareText)
            }
            startActivity(Intent.createChooser(intent, "Share App"))
        }
        
        private fun openUrl(url: String) {
            try {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                startActivity(intent)
            } catch (e: Exception) {
                showMessage("Cannot open URL: $url")
            }
        }
        
        private fun showMessage(message: String) {
            com.google.android.material.snackbar.Snackbar.make(
                requireView(),
                message,
                com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
            ).show()
        }
        
        override fun onResume() {
            super.onResume()
            updateSummaries()
        }
    }
}