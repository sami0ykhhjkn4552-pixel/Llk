package com.keyboard.kyntra.utils

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys

object SharedPrefs {
    
    private const val PREFS_NAME = "kyntra_keyboard_prefs"
    private const val ENCRYPTED_PREFS_NAME = "kyntra_encrypted_prefs"
    
    // مفاتيح التخزين
    private const val KEY_THEME_MODE = "theme_mode"
    private const val KEY_CURRENT_LANGUAGE = "current_language"
    private const val KEY_SOUND_ENABLED = "sound_enabled"
    private const val KEY_VIBRATION_ENABLED = "vibration_enabled"
    private const val KEY_VIBRATION_STRENGTH = "vibration_strength"
    private const val KEY_KEYBOARD_HEIGHT = "keyboard_height"
    private const val KEY_KEYBOARD_TRANSPARENCY = "keyboard_transparency"
    private const val KEY_SHOW_PASTE_NOTIFICATION = "show_paste_notification"
    private const val KEY_MASK_PASSWORDS = "mask_passwords"
    private const val KEY_EMOJI_FILTER_ENABLED = "emoji_filter_enabled"
    private const val KEY_WORD_FILTER_ENABLED = "word_filter_enabled"
    private const val KEY_AUTO_CORRECT_ENABLED = "auto_correct_enabled"
    private const val KEY_PREDICTIVE_TEXT_ENABLED = "predictive_text_enabled"
    private const val KEY_LAST_UPDATE_CHECK = "last_update_check"
    private const val KEY_FIRST_RUN = "first_run"
    private const val KEY_APP_VERSION = "app_version"
    private const val KEY_USER_ID = "user_id"
    
    // مفاتيح الإحصائيات
    private const val KEY_TOTAL_TYPED = "total_typed"
    private const val KEY_TOTAL_WORDS = "total_words"
    private const val KEY_TOTAL_EMOJIS = "total_emojis"
    private const val KEY_TOTAL_SYMBOLS = "total_symbols"
    private const val KEY_TOTAL_SECRETS = "total_secrets"
    
    // القيم الافتراضية
    private const val DEFAULT_THEME_MODE = "dark"
    private const val DEFAULT_LANGUAGE = "en"
    private const val DEFAULT_SOUND_ENABLED = true
    private const val DEFAULT_VIBRATION_ENABLED = true
    private const val DEFAULT_VIBRATION_STRENGTH = 50
    private const val DEFAULT_KEYBOARD_HEIGHT = 100
    private const val DEFAULT_KEYBOARD_TRANSPARENCY = 0
    private const val DEFAULT_SHOW_PASTE_NOTIFICATION = true
    private const val DEFAULT_MASK_PASSWORDS = true
    private const val DEFAULT_EMOJI_FILTER_ENABLED = true
    private const val DEFAULT_WORD_FILTER_ENABLED = true
    private const val DEFAULT_AUTO_CORRECT_ENABLED = true
    private const val DEFAULT_PREDICTIVE_TEXT_ENABLED = true
    private const val DEFAULT_FIRST_RUN = true
    
    private lateinit var sharedPrefs: SharedPreferences
    private lateinit var encryptedPrefs: SharedPreferences
    
    /**
     * تهيئة SharedPreferences
     */
    fun initialize(context: Context) {
        sharedPrefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        
        try {
            val masterKeyAlias = MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC)
            encryptedPrefs = EncryptedSharedPreferences.create(
                ENCRYPTED_PREFS_NAME,
                masterKeyAlias,
                context,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            // استخدام التخزين العادي إذا فشل التشفير
            encryptedPrefs = sharedPrefs
        }
        
        // التحقق من الإصدار الأول
        if (getBoolean(KEY_FIRST_RUN, DEFAULT_FIRST_RUN)) {
            setDefaults()
            setBoolean(KEY_FIRST_RUN, false)
        }
    }
    
    /**
     * تعيين القيم الافتراضية
     */
    private fun setDefaults() {
        setThemeMode(DEFAULT_THEME_MODE)
        setCurrentLanguage(DEFAULT_LANGUAGE)
        setSoundEnabled(DEFAULT_SOUND_ENABLED)
        setVibrationEnabled(DEFAULT_VIBRATION_ENABLED)
        setVibrationStrength(DEFAULT_VIBRATION_STRENGTH)
        setKeyboardHeight(DEFAULT_KEYBOARD_HEIGHT)
        setKeyboardTransparency(DEFAULT_KEYBOARD_TRANSPARENCY)
        setShowPasteNotification(DEFAULT_SHOW_PASTE_NOTIFICATION)
        setMaskPasswords(DEFAULT_MASK_PASSWORDS)
        setEmojiFilterEnabled(DEFAULT_EMOJI_FILTER_ENABLED)
        setWordFilterEnabled(DEFAULT_WORD_FILTER_ENABLED)
        setAutoCorrectEnabled(DEFAULT_AUTO_CORRECT_ENABLED)
        setPredictiveTextEnabled(DEFAULT_PREDICTIVE_TEXT_ENABLED)
    }
    
    // === وظائف السمة ===
    
    fun getThemeMode(context: Context): String {
        return getString(KEY_THEME_MODE, DEFAULT_THEME_MODE)
    }
    
    fun setThemeMode(context: Context, mode: String) {
        setString(KEY_THEME_MODE, mode)
    }
    
    // === وظائف اللغة ===
    
    fun getCurrentLanguage(context: Context): String {
        return getString(KEY_CURRENT_LANGUAGE, DEFAULT_LANGUAGE)
    }
    
    fun setCurrentLanguage(context: Context, languageCode: String) {
        setString(KEY_CURRENT_LANGUAGE, languageCode)
    }
    
    // === وظائف الصوت والاهتزاز ===
    
    fun getSoundEnabled(context: Context): Boolean {
        return getBoolean(KEY_SOUND_ENABLED, DEFAULT_SOUND_ENABLED)
    }
    
    fun setSoundEnabled(context: Context, enabled: Boolean) {
        setBoolean(KEY_SOUND_ENABLED, enabled)
    }
    
    fun getVibrationEnabled(context: Context): Boolean {
        return getBoolean(KEY_VIBRATION_ENABLED, DEFAULT_VIBRATION_ENABLED)
    }
    
    fun setVibrationEnabled(context: Context, enabled: Boolean) {
        setBoolean(KEY_VIBRATION_ENABLED, enabled)
    }
    
    fun getVibrationStrength(context: Context): Int {
        return getInt(KEY_VIBRATION_STRENGTH, DEFAULT_VIBRATION_STRENGTH)
    }
    
    fun setVibrationStrength(context: Context, strength: Int) {
        setInt(KEY_VIBRATION_STRENGTH, strength.coerceIn(0, 100))
    }
    
    // === وظائف مظهر لوحة المفاتيح ===
    
    fun getKeyboardHeight(context: Context): Int {
        return getInt(KEY_KEYBOARD_HEIGHT, DEFAULT_KEYBOARD_HEIGHT)
    }
    
    fun setKeyboardHeight(context: Context, height: Int) {
        setInt(KEY_KEYBOARD_HEIGHT, height.coerceIn(50, 150))
    }
    
    fun getKeyboardTransparency(context: Context): Int {
        return getInt(KEY_KEYBOARD_TRANSPARENCY, DEFAULT_KEYBOARD_TRANSPARENCY)
    }
    
    fun setKeyboardTransparency(context: Context, transparency: Int) {
        setInt(KEY_KEYBOARD_TRANSPARENCY, transparency.coerceIn(0, 80))
    }
    
    // === وظائف الأسرار ===
    
    fun getShowPasteNotification(context: Context): Boolean {
        return getBoolean(KEY_SHOW_PASTE_NOTIFICATION, DEFAULT_SHOW_PASTE_NOTIFICATION)
    }
    
    fun setShowPasteNotification(context: Context, show: Boolean) {
        setBoolean(KEY_SHOW_PASTE_NOTIFICATION, show)
    }
    
    fun getMaskPasswords(context: Context): Boolean {
        return getBoolean(KEY_MASK_PASSWORDS, DEFAULT_MASK_PASSWORDS)
    }
    
    fun setMaskPasswords(context: Context, mask: Boolean) {
        setBoolean(KEY_MASK_PASSWORDS, mask)
    }
    
    // === وظائف التصفية ===
    
    fun getEmojiFilterEnabled(context: Context): Boolean {
        return getBoolean(KEY_EMOJI_FILTER_ENABLED, DEFAULT_EMOJI_FILTER_ENABLED)
    }
    
    fun setEmojiFilterEnabled(context: Context, enabled: Boolean) {
        setBoolean(KEY_EMOJI_FILTER_ENABLED, enabled)
    }
    
    fun getWordFilterEnabled(context: Context): Boolean {
        return getBoolean(KEY_WORD_FILTER_ENABLED, DEFAULT_WORD_FILTER_ENABLED)
    }
    
    fun setWordFilterEnabled(context: Context, enabled: Boolean) {
        setBoolean(KEY_WORD_FILTER_ENABLED, enabled)
    }
    
    // === وظائف الكتابة الذكية ===
    
    fun getAutoCorrectEnabled(context: Context): Boolean {
        return getBoolean(KEY_AUTO_CORRECT_ENABLED, DEFAULT_AUTO_CORRECT_ENABLED)
    }
    
    fun setAutoCorrectEnabled(context: Context, enabled: Boolean) {
        setBoolean(KEY_AUTO_CORRECT_ENABLED, enabled)
    }
    
    fun getPredictiveTextEnabled(context: Context): Boolean {
        return getBoolean(KEY_PREDICTIVE_TEXT_ENABLED, DEFAULT_PREDICTIVE_TEXT_ENABLED)
    }
    
    fun setPredictiveTextEnabled(context: Context, enabled: Boolean) {
        setBoolean(KEY_PREDICTIVE_TEXT_ENABLED, enabled)
    }
    
    // === وظائف الإحصائيات ===
    
    fun getTotalTyped(context: Context): Long {
        return getLong(KEY_TOTAL_TYPED, 0L)
    }
    
    fun incrementTotalTyped(context: Context, amount: Int = 1) {
        val current = getTotalTyped(context)
        setLong(KEY_TOTAL_TYPED, current + amount)
    }
    
    fun getTotalWords(context: Context): Long {
        return getLong(KEY_TOTAL_WORDS, 0L)
    }
    
    fun incrementTotalWords(context: Context, amount: Int = 1) {
        val current = getTotalWords(context)
        setLong(KEY_TOTAL_WORDS, current + amount)
    }
    
    fun getTotalEmojis(context: Context): Long {
        return getLong(KEY_TOTAL_EMOJIS, 0L)
    }
    
    fun incrementTotalEmojis(context: Context, amount: Int = 1) {
        val current = getTotalEmojis(context)
        setLong(KEY_TOTAL_EMOJIS, current + amount)
    }
    
    fun getTotalSymbols(context: Context): Long {
        return getLong(KEY_TOTAL_SYMBOLS, 0L)
    }
    
    fun incrementTotalSymbols(context: Context, amount: Int = 1) {
        val current = getTotalSymbols(context)
        setLong(KEY_TOTAL_SYMBOLS, current + amount)
    }
    
    fun getTotalSecrets(context: Context): Long {
        return getLong(KEY_TOTAL_SECRETS, 0L)
    }
    
    fun incrementTotalSecrets(context: Context, amount: Int = 1) {
        val current = getTotalSecrets(context)
        setLong(KEY_TOTAL_SECRETS, current + amount)
    }
    
    // === وظائف التطبيق ===
    
    fun getLastUpdateCheck(context: Context): Long {
        return getLong(KEY_LAST_UPDATE_CHECK, 0L)
    }
    
    fun setLastUpdateCheck(context: Context, timestamp: Long) {
        setLong(KEY_LAST_UPDATE_CHECK, timestamp)
    }
    
    fun getAppVersion(context: Context): String {
        return getString(KEY_APP_VERSION, "")
    }
    
    fun setAppVersion(context: Context, version: String) {
        setString(KEY_APP_VERSION, version)
    }
    
    // === وظائف المستخدم ===
    
    fun getUserId(context: Context): String {
        return encryptedPrefs.getString(KEY_USER_ID, "") ?: ""
    }
    
    fun setUserId(context: Context, userId: String) {
        encryptedPrefs.edit().putString(KEY_USER_ID, userId).apply()
    }
    
    // === وظائف الإيموجيات والرموز ===
    
    fun getFavoriteEmojis(context: Context): String {
        return encryptedPrefs.getString("favorite_emojis", "") ?: ""
    }
    
    fun setFavoriteEmojis(context: Context, json: String) {
        encryptedPrefs.edit().putString("favorite_emojis", json).apply()
    }
    
    fun getRecentEmojis(context: Context): String {
        return encryptedPrefs.getString("recent_emojis", "") ?: ""
    }
    
    fun setRecentEmojis(context: Context, json: String) {
        encryptedPrefs.edit().putString("recent_emojis", json).apply()
    }
    
    fun getEmojiUsageCount(context: Context): Map<String, Int> {
        val json = encryptedPrefs.getString("emoji_usage", "") ?: ""
        return if (json.isNotEmpty()) {
            try {
                val type = object : com.google.gson.reflect.TypeToken<Map<String, Int>>() {}.type
                com.google.gson.Gson().fromJson(json, type)
            } catch (e: Exception) {
                emptyMap()
            }
        } else {
            emptyMap()
        }
    }
    
    fun setEmojiUsageCount(context: Context, usage: Map<String, Int>) {
        val json = com.google.gson.Gson().toJson(usage)
        encryptedPrefs.edit().putString("emoji_usage", json).apply()
    }
    
    fun getFavoriteSymbols(context: Context): String {
        return encryptedPrefs.getString("favorite_symbols", "") ?: ""
    }
    
    fun setFavoriteSymbols(context: Context, json: String) {
        encryptedPrefs.edit().putString("favorite_symbols", json).apply()
    }
    
    fun getSymbolUsageCount(context: Context): Map<String, Int> {
        val json = encryptedPrefs.getString("symbol_usage", "") ?: ""
        return if (json.isNotEmpty()) {
            try {
                val type = object : com.google.gson.reflect.TypeToken<Map<String, Int>>() {}.type
                com.google.gson.Gson().fromJson(json, type)
            } catch (e: Exception) {
                emptyMap()
            }
        } else {
            emptyMap()
        }
    }
    
    fun setSymbolUsageCount(context: Context, usage: Map<String, Int>) {
        val json = com.google.gson.Gson().toJson(usage)
        encryptedPrefs.edit().putString("symbol_usage", json).apply()
    }
    
    // === وظائف إحصائيات اللصق ===
    
    fun getPasteStats(context: Context): Map<String, Int> {
        val json = encryptedPrefs.getString("paste_stats", "") ?: ""
        return if (json.isNotEmpty()) {
            try {
                val type = object : com.google.gson.reflect.TypeToken<Map<String, Int>>() {}.type
                com.google.gson.Gson().fromJson(json, type)
            } catch (e: Exception) {
                emptyMap()
            }
        } else {
            emptyMap()
        }
    }
    
    fun setPasteStats(context: Context, stats: Map<String, Int>) {
        val json = com.google.gson.Gson().toJson(stats)
        encryptedPrefs.edit().putString("paste_stats", json).apply()
    }
    
    fun clearPasteStats(context: Context) {
        encryptedPrefs.edit().remove("paste_stats").apply()
    }
    
    fun getPasteLengthStats(context: Context): Map<String, Int> {
        val json = encryptedPrefs.getString("paste_length_stats", "") ?: ""
        return if (json.isNotEmpty()) {
            try {
                val type = object : com.google.gson.reflect.TypeToken<Map<String, Int>>() {}.type
                com.google.gson.Gson().fromJson(json, type)
            } catch (e: Exception) {
                emptyMap()
            }
        } else {
            emptyMap()
        }
    }
    
    fun setPasteLengthStats(context: Context, stats: Map<String, Int>) {
        val json = com.google.gson.Gson().toJson(stats)
        encryptedPrefs.edit().putString("paste_length_stats", json).apply()
    }
    
    fun clearPasteLengthStats(context: Context) {
        encryptedPrefs.edit().remove("paste_length_stats").apply()
    }
    
    fun getSmartPasteStats(context: Context): Map<String, Int> {
        val json = encryptedPrefs.getString("smart_paste_stats", "") ?: ""
        return if (json.isNotEmpty()) {
            try {
                val type = object : com.google.gson.reflect.TypeToken<Map<String, Int>>() {}.type
                com.google.gson.Gson().fromJson(json, type)
            } catch (e: Exception) {
                emptyMap()
            }
        } else {
            emptyMap()
        }
    }
    
    fun setSmartPasteStats(context: Context, stats: Map<String, Int>) {
        val json = com.google.gson.Gson().toJson(stats)
        encryptedPrefs.edit().putString("smart_paste_stats", json).apply()
    }
    
    fun clearSmartPasteStats(context: Context) {
        encryptedPrefs.edit().remove("smart_paste_stats").apply()
    }
    
    // === وظائف عامة ===
    
    private fun getString(key: String, defaultValue: String): String {
        return sharedPrefs.getString(key, defaultValue) ?: defaultValue
    }
    
    private fun setString(key: String, value: String) {
        sharedPrefs.edit().putString(key, value).apply()
    }
    
    private fun getBoolean(key: String, defaultValue: Boolean): Boolean {
        return sharedPrefs.getBoolean(key, defaultValue)
    }
    
    private fun setBoolean(key: String, value: Boolean) {
        sharedPrefs.edit().putBoolean(key, value).apply()
    }
    
    private fun getInt(key: String, defaultValue: Int): Int {
        return sharedPrefs.getInt(key, defaultValue)
    }
    
    private fun setInt(key: String, value: Int) {
        sharedPrefs.edit().putInt(key, value).apply()
    }
    
    private fun getLong(key: String, defaultValue: Long): Long {
        return sharedPrefs.getLong(key, defaultValue)
    }
    
    private fun setLong(key: String, value: Long) {
        sharedPrefs.edit().putLong(key, value).apply()
    }
    
    private fun getFloat(key: String, defaultValue: Float): Float {
        return sharedPrefs.getFloat(key, defaultValue)
    }
    
    private fun setFloat(key: String, value: Float) {
        sharedPrefs.edit().putFloat(key, value).apply()
    }
    
    /**
     * مسح جميع البيانات (لأغراض التصحيح)
     */
    fun clearAll(context: Context) {
        sharedPrefs.edit().clear().apply()
        encryptedPrefs.edit().clear().apply()
        setDefaults()
    }
    
    /**
     * الحصول على جميع الإحصائيات
     */
    fun getAllStats(context: Context): Map<String, Any> {
        return mapOf(
            "total_typed" to getTotalTyped(context),
            "total_words" to getTotalWords(context),
            "total_emojis" to getTotalEmojis(context),
            "total_symbols" to getTotalSymbols(context),
            "total_secrets" to getTotalSecrets(context),
            "paste_stats" to getPasteStats(context),
            "paste_length_stats" to getPasteLengthStats(context),
            "smart_paste_stats" to getSmartPasteStats(context),
            "emoji_usage" to getEmojiUsageCount(context).size,
            "symbol_usage" to getSymbolUsageCount(context).size,
            "theme_mode" to getThemeMode(context),
            "current_language" to getCurrentLanguage(context),
            "sound_enabled" to getSoundEnabled(context),
            "vibration_enabled" to getVibrationEnabled(context)
        )
    }
    
    /**
     * تصدير جميع الإعدادات (لأغراض النسخ الاحتياطي)
     */
    fun exportSettings(context: Context): String {
        val settings = mutableMapOf<String, Any>()
        
        // جمع جميع الإعدادات
        sharedPrefs.all.forEach { (key, value) ->
            settings[key] = value
        }
        
        // إضافة بعض الإعدادات المشفرة
        settings["user_id"] = getUserId(context)
        settings["favorite_emojis"] = getFavoriteEmojis(context)
        settings["favorite_symbols"] = getFavoriteSymbols(context)
        
        return com.google.gson.Gson().toJson(settings)
    }
    
    /**
     * استيراد الإعدادات
     */
    fun importSettings(context: Context, json: String): Boolean {
        return try {
            val type = object : com.google.gson.reflect.TypeToken<Map<String, Any>>() {}.type
            val settings = com.google.gson.Gson().fromJson<Map<String, Any>>(json, type)
            
            val editor = sharedPrefs.edit()
            settings.forEach { (key, value) ->
                when (value) {
                    is String -> editor.putString(key, value)
                    is Boolean -> editor.putBoolean(key, value)
                    is Int -> editor.putInt(key, value)
                    is Long -> editor.putLong(key, value)
                    is Float -> editor.putFloat(key, value)
                }
            }
            editor.apply()
            
            true
        } catch (e: Exception) {
            false
        }
    }
}