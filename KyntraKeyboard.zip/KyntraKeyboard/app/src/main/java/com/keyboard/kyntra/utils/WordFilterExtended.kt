package com.keyboard.kyntra.utils

import android.content.Context
import android.content.res.Resources
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader

class WordFilterExtended(private val context: Context) {
    
    companion object {
        private const val TAG = "WordFilterExtended"
        
        // اللغات المدعومة
        private val SUPPORTED_LANGUAGES = listOf(
            "ar", // العربية
            "en", // الإنجليزية
            "fr", // الفرنسية
            "de", // الألمانية
            "es", // الإسبانية
            "ru", // الروسية
            "ja", // اليابانية
            "ko", // الكورية
            "hi", // الهندية
            "tr"  // التركية
        )
        
        // أنماط التهرب
        private val EVASION_PATTERNS = listOf(
            Regex("\\d"),                     // استبدال أحرف بأرقام
            Regex("[._\\-]"),                 // إضافة فواصل
            Regex("@|4|\\$|5"),              // استبدال الأحرف المتشابهة
            Regex("\\s+"),                    // مسافات متعددة
            Regex("(.)\\1{2,}"),              // تكرار أحرف
            Regex("[^\\p{L}\\p{N}\\s]"),      // رموز خاصة
            Regex("\\p{InArabic}"),           // أحرف عربية
            Regex("\\p{InCyrillic}"),         // أحرف سيريلية
            Regex("\\p{InHiragana}"),         // هيراغانا يابانية
            Regex("\\p{InKatakana}"),         // كاتاكانا يابانية
            Regex("\\p{InHangul}")            // هانغول كورية
        )
    }
    
    private val badWords = mutableMapOf<String, MutableSet<String>>()
    private var isInitialized = false
    private val initializationLock = Any()
    
    /**
     * تهيئة المصفاة
     */
    fun initialize(callback: (Boolean) -> Unit = {}) {
        if (isInitialized) {
            callback(true)
            return
        }
        
        CoroutineScope(Dispatchers.IO).launch {
            synchronized(initializationLock) {
                if (isInitialized) {
                    withContext(Dispatchers.Main) { callback(true) }
                    return@launch
                }
                
                try {
                    SUPPORTED_LANGUAGES.forEach { languageCode ->
                        loadBadWordsForLanguage(languageCode)
                    }
                    
                    isInitialized = true
                    Log.d(TAG, "Word filter initialized with ${badWords.values.sumOf { it.size }} words")
                    
                    withContext(Dispatchers.Main) { callback(true) }
                } catch (e: Exception) {
                    Log.e(TAG, "Failed to initialize word filter", e)
                    withContext(Dispatchers.Main) { callback(false) }
                }
            }
        }
    }
    
    /**
     * تحميل الكلمات البذيئة للغة معينة
     */
    private fun loadBadWordsForLanguage(languageCode: String) {
        val wordSet = mutableSetOf<String>()
        
        try {
            // تحميل من الملفات الخام
            val resourceName = "badwords_${languageCode}.txt"
            val resourceId = context.resources.getIdentifier(
                resourceName,
                "raw",
                context.packageName
            )
            
            if (resourceId != 0) {
                val inputStream = context.resources.openRawResource(resourceId)
                BufferedReader(InputStreamReader(inputStream, Charsets.UTF_8)).use { reader ->
                    reader.forEachLine { line ->
                        val word = line.trim()
                        if (word.isNotBlank() && !word.startsWith("#")) {
                            wordSet.add(word.lowercase())
                            // إضافة أشكال متغيرة للكلمة
                            addVariations(word, wordSet)
                        }
                    }
                }
            }
            
            badWords[languageCode] = wordSet
            Log.d(TAG, "Loaded ${wordSet.size} bad words for language: $languageCode")
        } catch (e: Resources.NotFoundException) {
            Log.w(TAG, "No bad words file found for language: $languageCode")
        } catch (e: Exception) {
            Log.e(TAG, "Error loading bad words for language: $languageCode", e)
        }
    }
    
    /**
     * إضافة أشكال متغيرة للكلمة
     */
    private fun addVariations(word: String, wordSet: MutableSet<String>) {
        val lowercase = word.lowercase()
        wordSet.add(lowercase)
        
        // إضافة أشكال بالحروف الكبيرة
        wordSet.add(word.uppercase())
        wordSet.add(word.replaceFirstChar { it.uppercase() })
        
        // إضافة أشكال مع استبدال الأحرف المتشابهة
        val variations = generateCharacterVariations(lowercase)
        wordSet.addAll(variations)
        
        // إضافة أشكال مع حذف المسافات
        if (word.contains(" ")) {
            wordSet.add(word.replace(" ", ""))
            wordSet.add(word.replace(" ", "_"))
            wordSet.add(word.replace(" ", "."))
            wordSet.add(word.replace(" ", "-"))
        }
    }
    
    /**
     * توليد أشكال متغيرة للأحرف
     */
    private fun generateCharacterVariations(word: String): Set<String> {
        val variations = mutableSetOf<String>()
        
        // استبدال الأحرف المتشابهة
        val charMap = mapOf(
            'a' to listOf("@", "4", "á", "à", "â", "ä"),
            'e' to listOf("3", "é", "è", "ê", "ë"),
            'i' to listOf("1", "!", "í", "ì", "î", "ï"),
            'o' to listOf("0", "ó", "ò", "ô", "ö"),
            's' to listOf("5", "$", "ś", "š"),
            't' to listOf("7", "ţ", "ť"),
            'b' to listOf("8", "ß"),
            'g' to listOf("9", "ğ"),
            'l' to listOf("1", "ł"),
            'z' to listOf("2", "ž", "ź")
        )
        
        // توليد مجموعة من التباديل
        fun generatePermutations(current: String, index: Int) {
            if (index == word.length) {
                variations.add(current)
                return
            }
            
            val char = word[index]
            val charVariations = charMap[char] ?: listOf(char.toString())
            
            for (variation in charVariations) {
                generatePermutations(current + variation, index + 1)
            }
            
            // الحرف الأصلي
            generatePermutations(current + char, index + 1)
        }
        
        generatePermutations("", 0)
        return variations
    }
    
    /**
     * التحقق مما إذا كان النص يحتوي على كلمات بذيئة
     */
    fun containsBadWord(text: String, languageCode: String = "en"): Boolean {
        if (!isInitialized || text.isBlank()) {
            return false
        }
        
        val languageWords = badWords[languageCode] ?: badWords["en"] ?: return false
        
        // تنظيف النص للتحقق
        val cleanedText = prepareTextForChecking(text)
        
        // تقسيم النص إلى كلمات
        val words = cleanedText.split(Regex("\\s+|[.,!?;:]"))
        
        // التحقق من كل كلمة
        for (word in words) {
            if (word.length < 3) continue // تجاهل الكلمات القصيرة
            
            val normalizedWord = normalizeWord(word)
            if (languageWords.contains(normalizedWord)) {
                Log.d(TAG, "Found bad word: $normalizedWord in text: $text")
                return true
            }
            
            // التحقق من الأشكال المتغيرة
            if (checkWordVariations(normalizedWord, languageWords)) {
                return true
            }
        }
        
        // التحقق من الكلمات المركبة
        return checkCombinedWords(cleanedText, languageWords)
    }
    
    /**
     * تحضير النص للفحص
     */
    private fun prepareTextForChecking(text: String): String {
        var cleaned = text.lowercase()
        
        // إزالة أنماط التهرب
        EVASION_PATTERNS.forEach { pattern ->
            cleaned = cleaned.replace(pattern, "")
        }
        
        // إزالة التكرار المفرط للأحرف (مثل: hiiiiii -> hi)
        cleaned = cleaned.replace(Regex("(.)\\1{2,}"), "$1$1")
        
        return cleaned
    }
    
    /**
     * تطبيع الكلمة
     */
    private fun normalizeWord(word: String): String {
        var normalized = word.lowercase()
        
        // استبدال الأحرف المتشابهة بأصلها
        val replacementMap = mapOf(
            "@" to "a", "4" to "a",
            "3" to "e",
            "1" to "i", "!" to "i",
            "0" to "o",
            "5" to "s", "$" to "s",
            "7" to "t",
            "8" to "b",
            "9" to "g",
            "_" to "", "." to "", "-" to ""
        )
        
        replacementMap.forEach { (from, to) ->
            normalized = normalized.replace(from, to)
        }
        
        return normalized
    }
    
    /**
     * التحقق من أشكال الكلمة المتغيرة
     */
    private fun checkWordVariations(word: String, wordSet: Set<String>): Boolean {
        // التحقق من الكلمة نفسها
        if (wordSet.contains(word)) return true
        
        // التحقق من الأشكال مع حذف الأحرف
        for (i in word.indices) {
            val modified = word.removeRange(i, i + 1)
            if (wordSet.contains(modified)) return true
        }
        
        // التحقق من الأشكال مع إضافة أحرف
        for (i in word.indices) {
            for (char in 'a'..'z') {
                val modified = word.substring(0, i) + char + word.substring(i)
                if (wordSet.contains(modified)) return true
            }
        }
        
        // التحقق من الأشكال مع استبدال الأحرف
        for (i in word.indices) {
            for (char in 'a'..'z') {
                val modified = word.substring(0, i) + char + word.substring(i + 1)
                if (wordSet.contains(modified)) return true
            }
        }
        
        return false
    }
    
    /**
     * التحقق من الكلمات المركبة
     */
    private fun checkCombinedWords(text: String, wordSet: Set<String>): Boolean {
        // التحقق من تركيبات الكلمات (مثل: badword -> bad word)
        for (i in 3 until text.length - 2) {
            val part1 = text.substring(0, i)
            val part2 = text.substring(i)
            
            if (wordSet.contains(part1) && wordSet.contains(part2)) {
                return true
            }
            
            if (wordSet.contains(part1) || wordSet.contains(part2)) {
                // يمكن إضافة مزيد من المنطق هنا
                continue
            }
        }
        
        return false
    }
    
    /**
     * تصفية النص
     */
    fun filterText(text: String, languageCode: String = "en", replacement: String = "***"): String {
        if (!isInitialized || text.isBlank()) {
            return text
        }
        
        val languageWords = badWords[languageCode] ?: badWords["en"] ?: return text
        
        // تقسيم النص إلى كلمات مع الحفاظ على المسافات والترقيم
        val pattern = Regex("(\\b\\w+\\b|[^\\w\\s])")
        val words = pattern.findAll(text).map { it.value }.toList()
        
        val filteredWords = words.map { word ->
            val normalized = normalizeWord(word)
            
            if (word.length >= 3 && (languageWords.contains(normalized) || 
                checkWordVariations(normalized, languageWords))) {
                replacement
            } else {
                word
            }
        }
        
        return filteredWords.joinToString("")
    }
    
    /**
     * الحصول على قائمة الكلمات البذيئة للغة
     */
    fun getBadWords(languageCode: String): Set<String> {
        return badWords[languageCode]?.toSet() ?: emptySet()
    }
    
    /**
     * إضافة كلمة بذيئة يدويًا (للتحديثات الديناميكية)
     */
    fun addBadWord(word: String, languageCode: String = "en"): Boolean {
        if (!isInitialized) {
            initialize()
        }
        
        val wordSet = badWords[languageCode] ?: run {
            val newSet = mutableSetOf<String>()
            badWords[languageCode] = newSet
            newSet
        }
        
        val normalized = normalizeWord(word)
        return wordSet.add(normalized).also {
            if (it) {
                Log.d(TAG, "Added bad word: $normalized for language: $languageCode")
            }
        }
    }
    
    /**
     * إزالة كلمة من القائمة
     */
    fun removeBadWord(word: String, languageCode: String = "en"): Boolean {
        val wordSet = badWords[languageCode] ?: return false
        val normalized = normalizeWord(word)
        
        return wordSet.remove(normalized).also {
            if (it) {
                Log.d(TAG, "Removed bad word: $normalized from language: $languageCode")
            }
        }
    }
    
    /**
     * التحقق من وجود كلمة في القائمة
     */
    fun isBadWord(word: String, languageCode: String = "en"): Boolean {
        if (!isInitialized) return false
        
        val normalized = normalizeWord(word)
        val languageWords = badWords[languageCode] ?: badWords["en"] ?: return false
        
        return languageWords.contains(normalized) || checkWordVariations(normalized, languageWords)
    }
    
    /**
     * الحصول على إحصائيات المصفي
     */
    fun getStats(): Map<String, Any> {
        return mapOf(
            "initialized" to isInitialized,
            "languages_loaded" to badWords.keys.size,
            "total_words" to badWords.values.sumOf { it.size },
            "words_by_language" to badWords.mapValues { it.value.size }
        )
    }
    
    /**
     * مسح ذاكرة المصفي
     */
    fun clear() {
        badWords.clear()
        isInitialized = false
    }
    
    /**
     * تصدير قائمة الكلمات البذيئة
     */
    fun exportBadWords(languageCode: String = "en"): String {
        val wordSet = badWords[languageCode] ?: return ""
        return wordSet.sorted().joinToString("\n")
    }
    
    /**
     * استيراد قائمة كلمات بذيئة
     */
    fun importBadWords(words: String, languageCode: String = "en"): Int {
        if (!isInitialized) {
            initialize()
        }
        
        val wordSet = badWords[languageCode] ?: run {
            val newSet = mutableSetOf<String>()
            badWords[languageCode] = newSet
            newSet
        }
        
        val importedWords = words.split("\n", ",", ";")
            .map { it.trim() }
            .filter { it.isNotBlank() && !it.startsWith("#") }
        
        var count = 0
        importedWords.forEach { word ->
            val normalized = normalizeWord(word)
            if (wordSet.add(normalized)) {
                count++
            }
        }
        
        Log.d(TAG, "Imported $count bad words for language: $languageCode")
        return count
    }
}